import copy,json,re,html,unicodedata
from pathlib import Path
from collections import defaultdict,Counter
from text_localization import macros,tag_tokens
D=Path(__file__).resolve().parent;W=D.parent;R=W/'anachronism-cn'
def j(p):return json.loads(p.read_text('utf-8-sig'))
def norm(s):return re.sub(r'\s+',' ',html.unescape(unicodedata.normalize('NFKC',str(s))).replace('’',"'")).casefold().strip()
original=j(W/'source-cache/repo-original-export.json');plan=j(D/'name-plan.json');groups=[]
for r in plan.values():
 groups.append({'en':r['en'],'aliases':list(set([r['en']]+r.get('EnglishAliases',[]))),'old':r['current'],'new':r['proposed'],'ids':[r['id']],'kind':r['kind']})
 for alias in r.get('additionalOldChinese',[]):groups.append({'en':r['en'],'aliases':[r['en']],'old':alias,'new':r['proposed'],'ids':[r['id']],'kind':r['kind']})
 if r.get('referenceBase'):
  b=r['referenceBase'];groups.append({'en':b['English'],'aliases':[b['English']],'old':b['oldChinese'],'new':b['Chinese'],'ids':[r['id']],'kind':r['kind']})
for g in list(groups):
 if g['en']=='Virtual Storage':groups.append({**g,'old':'虚拟储物空间'})
 if g['en']=='Empathic Assistance':g['aliases'].append('Empathetic Assistance')
 if g['en']=='Disable Hardlight Projector':groups.append({**g,'old':'关闭硬光投影仪'})
 if g['en']=='Hardlight Body':groups.append({**g,'old':'硬光躯体'})
# Related effects share the same named rule but retain their source identities.
for g in groups:
 for pack in original.values():
  for obj in pack['entries'].values():
   if not isinstance(obj,dict) or obj.get('type')!='effect':continue
   base=re.sub(r'^(?:Spell )?Effect: *','',obj.get('name',''),flags=re.I)
   if any(norm(base)==norm(a) for a in g['aliases']):g['ids'].append(obj['_id'])
(D/'replacement-groups.json').write_bytes(json.dumps(groups,ensure_ascii=False,indent=2).encode('utf-8'))
byold=defaultdict(list)
for g in groups:byold[g['old']].append(g)
cnpat=re.compile('|'.join(re.escape(k) for k in sorted(byold,key=len,reverse=True)))
tagpat=re.compile(r'(</?[A-Za-z][^>]*>|<!--.*?-->)',re.S)
def get(o,path):
 for part in path.split('.'):
  if isinstance(o,list):o=o[int(part)] if part.isdigit() and int(part)<len(o) else None
  elif isinstance(o,dict):o=o.get(part)
  else:return None
 return o
def englishmatch(text,en):return re.search(r'(?<![a-z0-9])'+re.escape(norm(en))+r'(?:s)?(?![a-z0-9])',norm(text)) is not None
def references(en,g):return any(re.search(r'Compendium\.sf2e-anachronism\.[A-Za-z0-9_-]+\.(?:Item\.|JournalEntry\.)?'+re.escape(id)+r'(?:\]|\b)',en) for id in g['ids'])
def eligible(en,g):
 if g['kind']=='background' or g['en']=='Big Wet Eye Blink':return False
 if references(en,g):return True
 if g['en'] in ['Listen','Swap','Fidget','Contaminate','Puff Up']:
  return norm(en).strip(' :!')==norm(g['en']).strip(' :!')
 if g.get('namedMarkupOnly'):return norm(en).strip()==norm(g['en'])
 return any(englishmatch(en,a) for a in g['aliases'])
rows=j(D/'aligned-catalogue.json');canonById={r['id']:r for r in rows};canonEn=defaultdict(list)
for r in rows:
 for en in [r['en']]+r.get('EnglishAliases',[]):canonEn[norm(en).strip(' :!')].append(r)
def canonical(en):
 hits=canonEn.get(norm(en).strip(' :!'),[])
 return hits[0] if hits and len({r['proposed'] or r['current'] for r in hits})==1 else None
def display_name(old,en,r):
 cn=r['proposed'] or r['current'];return cn+(' '+en if en in old and norm(cn)!=norm(en) else '')
macroPat=re.compile(r'@UUID\[([^\]]+)\](?:\{([^{}]*)\})?')
def captions(old,en):
 sm=list(macroPat.finditer(en));cm=list(macroPat.finditer(old))
 if len(sm)!=len(cm):return old,[]
 out=[];edits=[]
 for a,b in zip(sm,cm):
  if a[1]!=b[1] or not b[2]:continue
  id=a[1].split('.')[-1];r=canonById.get(id)
  if not r or 'Compendium.sf2e-anachronism.' not in a[1]:continue
  if a[2] and norm(a[2]).strip(' :!') not in {norm(v).strip(' :!') for v in [r['en']]+r.get('EnglishAliases',[])}:continue
  cn=r['proposed'] or r['current'];label=cn+(' '+a[2] if a[2] and a[2] in b[2] else '')
  if b[2]!=label:edits.append((b.start(2),b.end(2),label));out.append(r['en'])
 for start,end,new in reversed(edits):old=old[:start]+new+old[end:]
 return old,out
changes=[];held=[];updated={};allunits=[]
def edit(file,path,owner,field,old,en,src):
 assert isinstance(en,str),(file,path,'English unavailable')
 reasons=[];new=old
 primary=canonById.get(src.get('_id'))
 if field=='name' and primary and norm(src.get('name'))==norm(primary['en']):
  new=display_name(old,en,primary);reasons.append('reviewed-primary-name')
 elif field=='name' and src.get('type')=='effect' and re.match(r'^(?:Spell )?Effect: *',en,re.I):
  base=re.sub(r'^(?:Spell )?Effect: *','',en,flags=re.I);r=canonical(base)
  if r:
   prefix=re.match(r'^.*?[:：] *',old)[0] if re.match(r'^.*?[:：] *',old) else ('法术效果：' if en.lower().startswith('spell effect:') else '效果：')
   new=prefix+(r['proposed'] or r['current'])+(' '+en if en in old else '');reasons.append('same-named-effect-display')
 else:
  # Exact displayed labels/headings only. Ordinary prose homonyms are not names.
  a=tagpat.split(old);b=tagpat.split(en);aligned=len(a)==len(b) and all(a[i]==b[i] for i in range(1,len(a),2))
  for i in range(0,len(a),2):
   english=b[i] if aligned else en
   r=canonical(english)
   if r and r['kind']=='background' and src.get('type')!='background':r=None
   if r and (field!='name') and re.search('[\u3400-\u9fff]',a[i]) and not re.search(r'[@\[<]',english) and english==english.strip():
    tail=re.search(r'[:：!?！?]\s*$',a[i]);suffix=tail[0] if tail else ''
    a[i]=display_name(a[i].removesuffix(suffix) if suffix else a[i],english.strip().rstrip(':! '),r)+suffix;reasons.append('exact-displayed-name:'+r['en'])
    continue
   def repl(m):
    candidates=[g for g in byold[m[0]] if eligible(english,g)]
    targets={g['new'] for g in candidates}
    if len(targets)==1:reasons.extend(g['en'] for g in candidates);return next(iter(targets))
    held.append({'file':file,'path':path,'old':m[0],'English':english,'Chinese':a[i],'reason':'ambiguous-target' if targets else 'no matching English or UUID in the text node'})
    return m[0]
   a[i]=cnpat.sub(repl,a[i])
  new=''.join(a)
  # Individually reviewed references with translated spelling variants or generic verbs.
  if src.get('name')=='Hot Swap' and 'gain the Swap action' in en and '交换动作' in new:
   new=new.replace('交换动作','换位动作');reasons.append('reviewed-Swap-action-reference')
  if src.get('name') in ['Disable Hardlight Projector','Project Hardlight Body'] and 'hardlight body' in en:
   new=new.replace('硬光躯体','实光躯体');reasons.append('reviewed-hardlight-body-reference')
  if src.get('name')=='Gap-Touched' and 'Gap-touched trait' in en:
   new=new.replace('断层触染特征','大断层接触者特征');reasons.append('reviewed-named-heritage-trait-reference')
  if src.get('name')=='Living Hologram' and 'tangible hardlight body' in en:
   new=new.replace('核心投射的实体实光躯体','核心投射出的有形实光躯体')
  new,rs=captions(new,en);reasons.extend('UUID-caption:'+r for r in rs)
 if new==old:return
 assert tag_tokens(old)==tag_tokens(new),(file,path,'HTML')
 assert [m['body'] for m in macros(old)]==[m['body'] for m in macros(new)],(file,path,'macro')
 assert re.findall(r'\d+(?:\.\d+)?',old)==re.findall(r'\d+(?:\.\d+)?',new),(file,path,'numbers')
 changes.append({'file':file,'path':path,'sourceName':src.get('name'),'sourceType':src.get('type'),'English':en,'old':old,'new':new,'reasons':sorted(set(reasons))});owner[field]=new

def collect_patch(file,patch,src,path):
 for field in ['name','description','content']:
  if field not in patch:continue
  p={'name':'name','description':'system.description.value','content':'text.content'}[field]
  en=get(src,p)
  if not isinstance(en,str):raise AssertionError((file,path,p))
  allunits.append((file,path+[field]));edit(file,path+[field],patch,field,patch[field],en,src)
 for field,patches in patch.items():
  if field in ['items','pages','subitems']:
   raw=src.get(field) if field!='subitems' else get(src,'system.subitems')
   assert isinstance(raw,list),(file,path,field)
   byid={s['_id']:s for s in raw}
   for i,p in enumerate(patches):
    item=byid[p['id']];assert item['name']==p['expectedName']
    collect_patch(file,p,item,path+[field,i])
  elif field=='extraFields':
   for i,p in enumerate(patches):
    en=get(src,p['path']);assert en==p['expected']
    edit(file,path+[field,i,'text'],p,'text',p['text'],en,src)
  elif field=='cnPrerequisites':
   for i,p in enumerate(patches):
    edit(file,path+[field,i,'text'],p,'text',p['text'],p['expected'],src)
  elif field.startswith('cnText_'):
   edit(file,path+[field,'text'],patches,'text',patches['text'],patches['expected'],src)
  elif field=='cnHolyModuleCorrection':
   edit(file,path+[field,'text'],patches,'text',patches['text'],patches['expectedDescription'],src)

for file,sourcepack in original.items():
 p=R/'translations'/file;tr=j(p);before=copy.deepcopy(tr)
 if not tr.get('mapping'):continue
 byid={s['_id']:s for s in sourcepack['entries'].values() if isinstance(s,dict)}
 for id,patch in tr['entries'].items():
  src=byid[id]
  if 'description' in patch and tr['mapping'].get('description')=='system.details.publicNotes':
   # Actor public notes have the same guarded text workflow, a different source path.
   edit(file,['entries',id,'description'],patch,'description',patch['description'],get(src,'system.details.publicNotes'),src)
   tmp={k:v for k,v in patch.items() if k!='description'};collect_patch(file,tmp,src,['entries',id]);patch.update(tmp)
  else:collect_patch(file,patch,src,['entries',id])
 if tr!=before:updated[file]=tr


(D/'proposed-translations').mkdir(exist_ok=True)
for file,data in updated.items():(D/'proposed-translations'/file).write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
(D/'proposals.json').write_bytes(json.dumps(changes,ensure_ascii=False,indent=2).encode('utf-8'))
(D/'held-references.json').write_bytes(json.dumps(held,ensure_ascii=False,indent=2).encode('utf-8'))
units=[];seen=set()
for c in changes:
 a=tagpat.split(c['old']);b=tagpat.split(c['new']);e=tagpat.split(c['English'])
 if len(a)!=len(b) or len(a)!=len(e):a=[c['old']];b=[c['new']];e=[c['English']]
 for x,y,z in zip(a,b,e):
  if x==y:continue
  sig=(z,x,y)
  if sig in seen:continue
  seen.add(sig);units.append({**{k:c[k] for k in ['file','path','sourceName','sourceType']},'English':z,'old':x,'new':y})
(D/'review-units.json').write_bytes(json.dumps(units,ensure_ascii=False,indent=2).encode('utf-8'))
print('FIELDS',len(changes),'PACKS',dict(Counter(c['file'] for c in changes)),'KINDS',dict(Counter(c['path'][-1] for c in changes)),'HELD',len(held),'UNIQUE UNITS',len(units))
