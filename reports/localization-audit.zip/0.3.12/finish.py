import json,re,hashlib,zipfile,shutil,subprocess
from pathlib import Path
from collections import Counter
from text_localization import macros,tag_tokens
D=Path(__file__).resolve().parent;W=D.parent;R=W/'anachronism-cn';O=W.parent/'outputs'
def j(p):return json.loads(p.read_text('utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
def key(s):return re.sub('[^a-z0-9+]','',s.casefold())
def save(p,obj):
 b=(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
 if p.exists() and b'\r\n' in p.read_bytes():b=b.replace(b'\n',b'\r\n')
 p.write_bytes(b)
before=j(D/'baseline-expected-export.json');after=j(D/'repo-expected-export.json');changes=j(D/'proposals.json');display=j(D/'display-proposals.json');plan=j(D/'name-plan.json');rows=j(D/'aligned-catalogue.json');diffs=[]
def compare(a,b,path):
 assert type(a)==type(b),(path,'type')
 if isinstance(a,dict):
  assert a.keys()==b.keys(),(path,'keys')
  for k in a:compare(a[k],b[k],path+[k])
 elif isinstance(a,list):
  assert len(a)==len(b),(path,'array')
  for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+[i])
 elif a!=b:
  assert isinstance(a,str) and re.search('[\u3400-\u9fff]',a),(path,'non-display data')
  joined='.'.join(map(str,path))
  assert path[-1] in ['name','label'] or re.search(r'\.system\.(?:description\.value|requirements|prerequisites\.value\.\d+\.value)$',joined) or joined.endswith('.text.content'),(path,'outside display paths')
  assert tag_tokens(a)==tag_tokens(b),(path,'HTML')
  assert [m['body'] for m in macros(a)]==[m['body'] for m in macros(b)],(path,'macro/UUID')
  assert re.findall(r'\d+(?:\.\d+)?',a)==re.findall(r'\d+(?:\.\d+)?',b),(path,'numbers')
  diffs.append({'path':path,'old':a,'new':b})
compare(before,after,[])
assert len(diffs)==len(changes)==154
assert Counter((c['old'],c['new']) for c in changes)==Counter((c['old'],c['new']) for c in diffs)
with zipfile.ZipFile(D/'baseline.zip') as z:
 oldvalidation=z.read('reports/validation.json');basev=json.loads(oldvalidation);termlines=z.read('reports/terms.tsv').decode('utf-8-sig').splitlines();expected=z.read('scripts/display-strings.mjs')
 for c in display:expected=expected.replace(json.dumps(c['old'],ensure_ascii=False).encode('utf-8'),json.dumps(c['new'],ensure_ascii=False).encode('utf-8'))
 assert expected==(R/'scripts/display-strings.mjs').read_bytes(),'display module changed outside reviewed literals'
 for n in ['scripts/register.mjs','scripts/display.mjs','tools/source-names.json','README.md','coverage.json']:
  assert z.read(n)==(R/n).read_bytes(),n
 assert z.read('translations/sf2e-anachronism.equipment.json')==(R/'translations/sf2e-anachronism.equipment.json').read_bytes()
source=j(W/'source-cache/repo-original-export.json');titles=j(R/'translations/titles.json');queries={}
for c in rows:
 cn=c['proposed'] or c['current'];displayname=cn+(' '+c['en'] if cn!=c['en'] else '');entry=j(R/'translations'/c['file'])['entries'][c['id']]
 assert entry['name']==displayname,(c['en'],entry['name'],displayname)
 collection=c['file'].removesuffix('.json');assert titles[collection]['titles'][c['id']]==displayname and titles[collection]['titles'][c['en']]==displayname
 if c['id'] in plan:
  hits=[v['_id'] for en,v in source[c['file']]['entries'].items() if cn in titles[collection]['titles'][v['_id']]]
  assert c['id'] in hits;queries[c['en']]={'Chinese':cn,'ids':hits}
assert len(plan)==67 and len(display)==6 and len(rows)==926
review=j(D/'review-complete.json');assert review['uniqueTranslationUnits']==152 and review['displayDictionaryUnits']==6
for unit in review['units']+review['displayDictionaryReview']:
 assert unit['sha256']==sha(unit['new'].encode('utf-8')) and all(unit[k] for k in ['faithfulness','terminology','readability'])
master={key(en):(cn,en) for cn,en in (l.split('\t') for l in termlines)};assert len(master)==844
with zipfile.ZipFile(W.parent/'archives/terminology-review-2026-10-24.zip') as z:oldterms=json.loads(z.read('final-audit.json'))
classes={key(d['English']):d['decision'] for d in oldterms['decisions'] if d['decision'].startswith('retain-')}
for f in [O/'恒星武士水晶修订译名.tsv',R/'reports/equipment-term-corrections.tsv',R/'reports/spell-feat-term-corrections.tsv']:
 for line in f.read_text('utf-8-sig').splitlines():classes[key(line.split('\t')[1])]='retain-correction'
assert Counter(classes[k] for k in master)==Counter({'retain-new':614,'retain-correction':230})
pairs={key(en):(v['Chinese'],en) for en,v in j(D/'wave-pairs.json').items()};assert len(pairs)==90
for k,pair in pairs.items():master[k]=pair;classes[k]='retain-correction'
terms=''.join(cn+'\t'+en+'\n' for cn,en in sorted(master.values(),key=lambda p:p[1].casefold()))
wave=''.join(cn+'\t'+en+'\n' for cn,en in sorted(pairs.values(),key=lambda p:p[1].casefold()))
for f in [R/'reports/terms.tsv',O/'新增及修订译名汇总.tsv']:f.write_bytes(terms.encode('utf-8'))
for f in [R/'reports/character-option-term-corrections.tsv',O/'职业族裔背景修订译名.tsv']:f.write_bytes(wave.encode('utf-8'))
counts=Counter(classes[k] for k in master)
assert len(master)==907 and counts==Counter({'retain-new':590,'retain-correction':317})
notes='''本轮核对8个职业、153个职业能力、50个族裔、62个族裔能力、338个传承、164个背景，以及151个相关动作，共926个主条目名称。检查同时覆盖其它包中的关联显示引用，并非完整规则正文的逐句重译。

实际修订67个主条目名称：4个族裔能力、15个传承、16个背景、32个动作。8个职业和153个职业能力主名称已对齐；保留了必要的共享条目别名与编程语言原名。另统一23个已有名称在效果、前置条件、族裔介绍和链接显示中的异译；本轮中英文对照90行，累计去重907行。效果前缀和重复引用不重复计入译名。

处理原则：名称优先SF2 Wiki，核实同一条目与上下文；规则正文差异保留模组版本，不据Wiki覆盖数值和自动化。以下“模组原文”专指Anachronism 2.4.0数据，并非声称是官方最终规则。尚未确认原因的差异不归类为Wiki错译。

保留的正文差异：
1. Gap-Touched（大断层接触者）：模组原文对抗心灵效果豁免为+1 circumstance bonus（环境加值）；Wiki“大断层接触者传承”正文为+1状态加值。保留模组的环境加值与自动化。
2. Acquistive（功利主义者背景）：模组原文给Media Lore（媒体学识）；Wiki“Data:Backgrounds-Acquisitive.json”为医疗学识。只改名称，保留媒体学识及原自动授予内容。
3. Shimmering Dazzle（闪光眩目）：模组原文频率每小时一次；Wiki“希伦虫人族裔”写每日一次。保留模组频率。
4. Living Submersible（活体潜水器）：模组原文“your Speed becomes 0”；Wiki“飞螅族族裔”写只能使用游泳速度移动。保留模组的速度限制与规则。
5. Pickle Switch（腌菜开关）：模组原文影响“occupants of all other vehicles”（所有其它载具的乘员）；Wiki“Data:Feats-Hot Ride.json”写所有其它载具内的乘员需豁免、失败则目眩。保留模组目标范围与其现有结果表述，不自行补写失败条件。
6. Passionate Naturalist（热忱博物学家）：模组原文为Life Science Lore（生命科学学识），Wiki背景正文写科学学识。保留模组的生命科学学识。
7. Toxic Tear（毒性撕裂）：模组原文列出helpless（无助）；Wiki正文也列出无助并以译注推测可能应为禁足。未将该推测写入模组规则、状态或谓词。

身份、别名和文字核对说明：
1. Change Shape：星蛸族能力对应Wiki“星蛸族族裔”的形态变换；松鼠狐人的同名能力采用变身，不能跨族裔覆盖。保留形态变换及星蛸族原有规则。
2. Nuar：Wiki“牛尔人族裔”正确对应牛尔人；“拾荒蜗族族裔”的信息框原文误填NUAR，但正文标题为GNAREFUROID。已排除误填，不把两个族裔互换。
3. Resolve、Incredible Senses是共享职业能力，Wiki使节/特工分别出现决心/决意、惊人感官/超凡感官。保留共享主条目现有且有Wiki依据的决心、惊人感官。Legendary Armor同页有传奇装甲/护甲大师，保留传奇装甲。
4. Skirmisher、Sniper按特工专精采用游击兵、狙击手；不套用无人机或武器组的同名译法。SRO词表列“自主机器人/自律机器人”，保留允许的别名，不将斜杠列表当作名称。
5. FORTRUN、Viper、Servoshell、DPS++是编程语言名，按用户已确认的约定保留英文；LFAN缩写也不重复添加英文。
6. 名称以Wiki为主，显然用字错误作最小修正：夜行维斯客蜥人统一为夜行维斯克蜥人（同页族裔名维斯克蜥人）；直接了当规范为直截了当。
7. Mechanical Expertise / Wiki Mechanic Expertise；Solar Weapon Expertise / Solarian Weapon Expertise；Soldier Weapon Mastery / Soldier Mastery；Inscrutable / Indiscernible；Runha / Runja；Fire Flood / Fire Floud；Cataclyst / Catalyst；Acquistive / Acquisitive；Umbral Stride / Umbral Strid等，经所属条目和规则上下文确认对应。运行条目英文拼写、ID、slug和链接保持模组原样，本轮对照表同样保留模组英文以便定位。
8. “扒手 Pickpocket”背景改为街头扒手；同名PF2技能专长仍为扒手。普通句子中的交换、聆听、吸收光线等也不会因与能力同词而被强行改名。

132个主条目尚未确认可靠的完整Wiki标题对应，保留当前译名（包含已有补译），不据近似名称跨规则归并；这不表示Wiki绝对没有中文。已补查主/Data命名空间当前目录、正文双语引用、标题拼写变体、同族裔无英文能力栏及关联页面。完整逐条定位、页面修订号与保留理由见character-option-name-audit-0.3.12.json及localization-audit.zip。

资料访问：配置中的灰机MCP指向PF2；本轮使用已有SF2只读API客户端刷新834页，结合当前9191页目录及近期修订记录复用未变化缓存。没有修改Wiki或用户原始译名表。
验证：Babele 2.9.1原生转换5616条、按需/原生索引5613个名称通过。相对0.3.11，仅154处已复核显示字段及6个界面字典值变化；数值、规则条件、公式、UUID、ID、slug和链接目标保持。原有商用型圣洁模组2d4授权修正继续沿用。没有新增真实Foundry会话测试。
'''
for f in [R/'reports/character-option-audit-notes.txt',O/'职业族裔背景核对说明.txt']:f.write_bytes(notes.encode('utf-8'))
decisions=[]
for row in rows:
 obj={k:row[k] for k in ['file','id','en','current','proposed','kind','status','method']};obj['changed']=row['id'] in plan
 obj['authorities']=[{k:a[k] for k in ['en','zh','page','revid','row','notes','kind'] if k in a} for a in row['candidates']]
 if row.get('note'):obj['note']=row['note']
 elif row['status']=='unmatched':obj['note']='未确认完整标题可靠对应，保留当前译名。'
 if row.get('EnglishAliases'):obj['EnglishAliases']=row['EnglishAliases']
 decisions.append(obj)
scope=dict(Counter(r['kind'] for r in rows));corrected=dict(Counter(r['kind'] for r in plan.values()))
report={'version':'0.3.12','baselineVersion':'0.3.11','scope':scope,'statusCounts':{kind:dict(Counter(x['status'] for x in rows if x['kind']==kind)) for kind in scope},'primaryNamesCorrected':len(plan),'correctedByCategory':corrected,'translationDisplayFields':len(changes),'interfaceDictionaryValues':len(display),'displayFieldsChanged':len(changes)+len(display),'namingPolicy':'Wiki-first names; same-entity matching; obvious orthographic errors corrected; module rule differences retained and documented.','sourceAccess':{'site':'https://sf2.huijiwiki.com','method':'Local read-only Huiji API client; configured MCP points to PF2','currentNamespaceInventoryPages':9191,'pagesRefreshed':834,'unchangedCacheReusedWithRecentChangesInventory':True,'originalGlossaryRows':1493},'reviewScope':review['scope'],'reviewedUnits':len(review['units'])+len(display),'reviewPasses':['English identity and faithfulness comparison','Second English terminology/context comparison','Independent Chinese reading'],'mechanicalDataUnchangedFrom0311':True,'uuidMacroBodiesIdsSlugsNumbersUnchanged':True,'displayLogicAndRegistrationUnchanged':True,'terminology':{'wavePairs':len(pairs),'primaryCorrections':67,'referenceOnlyCorrections':23,'masterPairs':len(master),'newPairs':counts['retain-new'],'actualCorrectionPairs':counts['retain-correction'],'masterSha256':sha(terms.encode('utf-8')),'format':'Chinese TAB English; no heading, notes or extra columns; unique normalized English keys'},'contentDifferenceNotes':'reports/character-option-audit-notes.txt','decisions':decisions,'changes':changes,'displayDictionaryChanges':display}
save(R/'reports/character-option-name-audit-0.3.12.json',report);save(D/'baseline-scalar-diff.json',diffs)
save(R/'reports/search-index-validation-0.3.12.json',{'version':'0.3.12','primaryNamesAudited':926,'changedNamesChecked':67,'allChineseQueriesAndEnglishAliasesPassed':True,'allStableIdsPreserved':True,'queries':queries,'nativeAndOndemandIndex':j(D/'validation.json'),'liveFoundryTested':False})
v=basev.copy();v['previousMaintenanceUpdate']={'version':'0.3.11','record':basev['maintenanceUpdate']};v.update(j(D/'0312-validation.json'))
v['historicalValidationSnapshot']='reports/localization-audit.zip:0.3.12/baseline-validation-0.3.11.json';v['translationOutputHashes']={p.name:sha(p.read_bytes()) for p in sorted((R/'translations').glob('sf*.json'))};v['searchIndexOutputHashes']={n:sha((R/'translations'/n).read_bytes()) for n in ['titles.json','labels.json']};v['displayStringsSha256']=sha((R/'scripts/display-strings.mjs').read_bytes());v['searchIndexCompatibility']=j(D/'validation.json');v['maintenanceUpdate']={k:report[k] for k in ['baselineVersion','scope','primaryNamesCorrected','correctedByCategory','translationDisplayFields','interfaceDictionaryValues','displayFieldsChanged','namingPolicy','terminology']};v['maintenanceUpdate'].update({'report':'reports/character-option-name-audit-0.3.12.json','searchReport':'reports/search-index-validation-0.3.12.json','mechanicalDataUnchangedFromBaseline':True,'runtimeLogicUnchanged':True})
assert v['runtimeScriptSha256']==sha((R/'scripts/register.mjs').read_bytes());assert v['displayScriptSha256']==sha((R/'scripts/display.mjs').read_bytes());save(R/'reports/validation.json',v)
m=j(R/'module.json');m['version']='0.3.12';m['download']=m['download'].replace('/v0.3.11/','/v0.3.12/');(R/'module.json').write_bytes((json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
archive=R/'reports/localization-audit.zip';temp=D/'localization-audit-new.zip'
with zipfile.ZipFile(archive) as old,zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for info in old.infolist():
  if not info.filename.startswith('0.3.12/'):z.writestr(info,old.read(info.filename))
 z.writestr('0.3.12/baseline-validation-0.3.11.json',oldvalidation)
 for n in ['live-wiki.json','unmatched-body-evidence.json','catalogue.json','aligned-catalogue.json','name-plan.json','proposals.json','held-references.json','review-complete.json','replacement-groups.json','wave-pairs.json','display-proposals.json','0312-validation.json','validation.json','baseline-scalar-diff.json','catalogue.py','align.py','propose.py','propose-display.mjs','finish.py','test-indexes.mjs','validate.mjs']:
  z.write(D/n,'0.3.12/'+n)
assert zipfile.ZipFile(temp).testzip() is None;shutil.copyfile(temp,archive)
hashes={p.name:sha(p.read_bytes()) for p in (R/'translations').glob('*.json')};subprocess.run(['python','-X','utf8',str(R/'tools/build_search_indexes.py')],check=True,capture_output=True);assert hashes=={p.name:sha(p.read_bytes()) for p in (R/'translations').glob('*.json')}
files=[]
for n in ['module.json','coverage.json','scripts','translations','README.md','THIRD-PARTY-NOTICES.md','licenses','reports']:
 p=R/n;files.extend([p] if p.is_file() else sorted(x for x in p.rglob('*') if x.is_file()))
target=O/'anachronism-cn-0.3.12.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None;assert set(z.namelist())=={p.relative_to(R).as_posix() for p in files}
 for p in files:assert z.read(p.relative_to(R).as_posix())==p.read_bytes(),str(p)
shutil.copyfile(target,R/'dist/anachronism-cn.zip')
summary={'version':'0.3.12','packageFiles':len(files),'packageSha256':sha(target.read_bytes()),'packageBytes':target.stat().st_size,'archiveMatchesRepositoryBytes':True,'indexBuilderIdempotent':True,'automationAndSourceIdentityPreserved':True,'displayLogicUnchanged':True,'displayDictionaryValuesChanged':len(display),'primaryNamesCorrected':len(plan),'displayFieldsChanged':len(changes)+len(display),'waveTermPairs':len(pairs),'masterTermPairs':len(master),'masterNewPairs':counts['retain-new'],'masterCorrectionPairs':counts['retain-correction'],'published':False}
save(D/'delivery-validation.json',summary);print(json.dumps(summary,ensure_ascii=False))
