import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
const D=path.dirname(fileURLToPath(import.meta.url)),R=path.resolve(D,'../anachronism-cn');
const source=path.join(R,'scripts/display-strings.mjs');
const before=await import(pathToFileURL(source));
const groups=JSON.parse(await fs.readFile(path.join(D,'replacement-groups.json'),'utf8'));
const changes=[],replacements=new Map();
function update(en,cn,where){
 let result=cn;
 const hits=groups.filter(g=>en.toLowerCase().includes(g.en.toLowerCase())&&cn.includes(g.old));
 const options=new Map();
 for(const g of hits){if(options.has(g.old))assert.equal(options.get(g.old),g.new);options.set(g.old,g.new);}
 if(options.size){const pattern=new RegExp([...options.keys()].sort((a,b)=>b.length-a.length).map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|'),'g');result=cn.replace(pattern,x=>options.get(x));}
 if(result!==cn){changes.push({where,English:en,old:cn,new:result});if(replacements.has(cn))assert.equal(replacements.get(cn),result);replacements.set(cn,result);}
}
for(const [en,cn]of Object.entries(before.DISPLAY_STRINGS))update(en,cn,['DISPLAY_STRINGS',en]);
for(const [uuid,entry]of Object.entries(before.DISPLAY_GRANTED_NAMES)){
 if(!uuid.startsWith('Compendium.sf2e-anachronism.'))continue;
 const en=entry.expectedNames.join(' / ');update(en,entry.name,['DISPLAY_GRANTED_NAMES',uuid,'name']);
}
let code=await fs.readFile(source,'utf8');
for(const [a,b]of replacements){const from=JSON.stringify(a),to=JSON.stringify(b);assert(code.includes(from));code=code.replaceAll(from,to);}
const target=path.join(D,'proposed-display-strings.mjs');await fs.writeFile(target,code);
const after=await import(pathToFileURL(target));
for(const key of Object.keys(before)){
 const expected=structuredClone(before[key]);
 for(const c of changes.filter(c=>c.where[0]===key)){
  if(key==='DISPLAY_STRINGS')expected[c.where[1]]=c.new;else expected[c.where[1]].name=c.new;
 }
 assert.deepEqual(after[key],expected,key);
}
await fs.writeFile(path.join(D,'display-proposals.json'),JSON.stringify(changes,null,2));
console.log(JSON.stringify(changes,null,2));
