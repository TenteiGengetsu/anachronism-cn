import json,re,copy
from pathlib import Path
from collections import Counter
D=Path(__file__).resolve().parent
def j(p):return json.loads(p.read_text('utf-8-sig'))
def key(s):return re.sub('[^a-z0-9+]','',s.casefold())
rows=j(D/'catalogue.json');records=j(D/'name-records.json');pages=j(D/'all-wiki-pages.json')
def row(en,kind=None):
 hits=[r for r in rows if r['en']==en and (kind is None or r['kind']==kind)];assert len(hits)==1,(en,kind);return hits[0]
def alias(en,other,page=None):
 r=row(en);hits=[a for a in records if key(a['en'])==key(other) and (page is None or a['page']==page)]
 assert hits and len({h['zh'] for h in hits})==1,(en,other,page)
 r.update(candidates=hits,proposed=hits[0]['zh'],EnglishAliases=[other],method='reviewed-English-title-variant-and-same-rule-context')
def field(en,page,zh,marker,note=''):
 r=row(en);p=pages[page];text=p['content'];assert marker in text,(en,page,marker);at=text.find(marker)
 r.update(candidates=[{'en':en,'zh':zh,'page':page,'revid':p['revid'],'kind':'same-ancestry-ability-or-explicit-reference','description':text[max(0,at-80):at+1800]}],proposed=zh,method='same-parent-and-rule-context-reviewed',note=note)
for en,other,page in [
 ('Inscrutable','Indiscernible','使节'),('Mechanical Expertise','Mechanic Expertise','机械师'),
 ('Solar Weapon Expertise','Solarian Weapon Expertise','恒星武士'),('Soldier Fighting Style','Soldier Fighting Styles','战斗风格'),
 ('Armor Storm','Aromr Storm','战斗风格'),('Envoy Directives','Envoy Directive','使节'),('Soldier Weapon Mastery','Soldier Mastery','士兵'),
 ('Runha Mechanic Hardor','Runja Mechanic Hardor','坚叶族族裔'),('Fire Flood Fonqugon','Fire Floud Fonqugon','方贡族族裔'),
 ('Song of Ice Ord','Song of the Ice Ord','奥德族裔'),('Cataclyst Human','Catalyst Human','人类族裔'),
 ('Sand Roamer','Sand Roamer Pahtra','趴爪族族裔'),('Religious Scholar','Religions Scholar','Data:Backgrounds-Religions Scholar.json'),
 ('Acquistive','Acquisitive','Data:Backgrounds-Acquisitive.json'),('Umbral Stride','Umbral Strid','Data:Actions-Umbral Strid.json'),
 ('Coordinated Ambush!','Coordinate Ambush','Data:Actions-Coordinate Ambush.json')]:alias(en,other,page)
for en,zh,page,marker in [
 ('Doomsayer\'s Litany','预言者祷言','卡萨斯人族裔',"'''预言者祷言 Doomsayer's Litany'''"),
 ('Pickle Switch','腌菜开关','Data:Feats-Hot Ride.json','腌菜开关（Pickle Switch）'),
 ('Toxic Tear','毒性撕裂','Data:Feats-Tetrodotoxic Beak.json','毒性撕裂 Toxic Tear'),
 ('Phasic Flurry','相位连斩','Data:Spells-Monstrosity Form.json','相位连斩（Phasic Flurry）'),
 ('New Plan','新计划！','Data:Feats-Master Plan.json','新计划！ New Plan!'),
 ('Beginner\'s Luck','初学者幸运','Data:Feats-Lucky Improviser.json',"初学者幸运 Beginner's Luck"),
 ('Burrowing Charge','掘地冲锋','Data:Spells-Monstrosity Form.json','掘地冲锋（Burrowing Charge）'),
 ('Drill Rush','钻刺冲锋',"Data:Feats-Strike from the World's Core.json",'钻刺冲锋 Drill Rush'),
 ('Manifest Energy Wings','显化能量翼','萨瑟蝶人族裔','显化能量翼 Manifest Energy Wings'),
 ('Once More with Feeling','再试一次','Data:Feats-Improv Workshop.json','再试一次 Once More with Feeling'),
 ('Volosian Spit','沃洛西亚喷吐','Data:Feats-Volosian Spit.json','沃洛西亚喷吐 Volosian Spit'),
 ('Change Shape','形态变换','星蛸族族裔','|能力2=形态变换'),
 ('Genetic Adaptation','基因适应','飞螅族族裔','|能力1=基因适应'),
 ('Thoughtsense','思维感知','默思族族裔','|能力3=思维感知'),
 ('Oozy','泥怪身躯','方贡族族裔','|能力2=泥怪身躯'),
 ('Atrophied','萎缩','默思族族裔','|能力1=萎缩'),
 ('Six-Armed','六臂','轻灵兽族裔','|能力2=六臂'),
 ('Clan Crystal','氏族水晶','矮人族裔','|能力1=氏族水晶'),
 ('Plant Nourishment (Leshy)','植物营养（莱西）','莱西族裔','|能力2=植物营养'),
 ('Plant Nourishment (Hardor)','植物营养（坚叶族）','坚叶族族裔','|能力3=植物营养')]:
 if en=='Change Shape':row(en)['rejectedCandidates']=row(en)['candidates']
 field(en,page,zh,marker)
for en in ['FORTRUN','Servoshell','Viper','DPS++']:
 r=row(en);p=pages['编程语言'];assert en.casefold() in p['content'].casefold()
 r.update(proposed=r['current'],candidates=[{'en':en,'zh':r['current'],'page':p['title'],'revid':p['revid'],'kind':'programming-language-proper-name'}],method='user-confirmed-code-language-preserved',note='编程语言名称按用户此前确认保留英文；不是漏译。')
for en,page in [('Legendary Armor','士兵'),('Resolve','使节'),('Incredible Senses','使节'),('Skirmisher','特工专精'),('Sniper','特工专精'),('Nuar','牛尔人族裔')]:
 r=row(en);hits=[h for h in r['candidates'] if h['page']==page and h['zh']==r['current']];assert hits,(en,page)
 r.update(rejectedCandidates=[h for h in r['candidates'] if h not in hits],candidates=hits,proposed=r['current'],method='same-rule-context-existing-Wiki-name-retained')
 r['note']='共享职业能力保留Wiki已采用的现有名称，其他职业别名不强行覆盖。' if en in ['Resolve','Incredible Senses','Legendary Armor'] else '已按条目身份排除同名不同对象。'
r=row('SRO');r.update(proposed=r['current'],method='glossary-listed-alias-retained',note='词表“自主机器人/自律机器人”列出两个可用别名；当前自主机器人已是其中之一，不把斜杠列表写成名称。')
r=row('Nightstalker Vesk');assert r['current']=='夜行维斯客蜥人'
r.update(proposed='夜行维斯克蜥人',method='Wiki-title-with-canonical-ancestry-spelling',note='Wiki该传承标题将维斯克误写作维斯客；沿用同页族裔主名称维斯克蜥人，仅统一专名用字。')
r=row('Direct Approach');assert r['current']=='直接了当'
r.update(proposed='直截了当',method='Chinese-orthographic-correction',note='Wiki与模组旧译“直接了当”按成语规范统一为“直截了当”；不改变该巫洛格族裔能力的规则。')
r=row('Bounce Back');r['note']='Wiki同名人类专长降低受伤；模组此动作来自变形形态且为坠落后弹跳，不能按同名强行归并。'
for r in rows:
 r['status']='consistent' if r['current']==r['proposed'] else 'different' if r['proposed'] else 'unmatched'
plan={r['id']:r for r in rows if r['status']=='different'}
for name,data in [('aligned-catalogue.json',rows),('name-plan.json',plan)]:
 (D/name).write_bytes(json.dumps(data,ensure_ascii=False,indent=2).encode('utf-8'))
print('COUNTS',Counter((r['kind'],r['status']) for r in rows),'CHANGES',len(plan))
for r in plan.values():print(r['kind'],r['en'],r['current'],'=>',r['proposed'])
