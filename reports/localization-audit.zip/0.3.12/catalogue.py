import difflib,html,json,re,unicodedata
from pathlib import Path
from collections import Counter,defaultdict
D=Path(__file__).resolve().parent;W=D.parent;R=W/'anachronism-cn'
def j(p):return json.loads(p.read_text('utf-8-sig'))
def clean(s):
 s=html.unescape(unicodedata.normalize('NFKC',str(s))).translate(str.maketrans({'’':"'",'‘':"'",'–':'-','—':'-','‑':'-'}))
 return re.sub(r'\s+',' ',''.join(c for c in s if unicodedata.category(c)!='Cf')).strip()
def key(s):return re.sub('[^a-z0-9+]','',clean(s).casefold())
def zk(s):return re.sub(r'[\W_]','',clean(s).casefold())
def plain(s):
 s=re.sub(r'\[\[([^\]|]+)(?:\|([^\]]+))?\]\]',lambda m:m[2] or m[1],s)
 s=re.sub(r'\{\{[^{}]*\}\}|<[^>]*>|\[/?(?:b|i|u|size|color|font)(?:=[^]]*)?\]','',s,flags=re.I)
 s=clean(s.strip("=' "))
 return re.sub(r'^(?:多用传承|族裔|职业|传承)\s*[:：/]\s*','',s)
scope={'classes':'class','class-features':'class-feature','ancestries':'ancestry','ancestry-features':'ancestry-feature','heritages':'heritage','backgrounds':'background','actions':'action'}
source=j(W/'source-cache/repo-original-export.json');rows=[]
for pack,kind in scope.items():
 file='sf2e-anachronism.'+pack+'.json';tr=j(R/'translations'/file)['entries']
 for en,obj in source[file]['entries'].items():
  cn=tr[obj['_id']]['name'];cn=cn[:-len(en)-1] if cn.endswith(' '+en) else cn
  rows.append({'file':file,'id':obj['_id'],'en':en,'current':cn,'kind':kind,'traits':obj.get('system',{}).get('traits',{}).get('value',[]),'level':obj.get('system',{}).get('level'),'sourceDescription':obj.get('system',{}).get('description',{}).get('value','')})
pages=j(D/'all-wiki-pages.json');live=j(D/'live-wiki.json');current={p['title'] for p in live['inventory']};records=[];headers=[]
def add(en,zh,p,kind,**extra):
 if not isinstance(en,str) or not isinstance(zh,str) or not re.search('[\u3400-\u9fff]',zh):return
 zh=zh.strip(' ：:/|-')
 zh=re.sub(r'^(?:多用传承|族裔|职业|传承)\s*[:：/]\s*','',zh)
 zh=re.sub(r'^启动\s*[-—–:：]\s*','',zh)
 r={'en':en.strip(),'zh':zh.strip(),'page':p['title'],'revid':p['revid'],'kind':kind,**extra}
 if r not in records:records.append(r)
for title,p in pages.items():
 if title not in current or p.get('missing'):continue
 text=p.get('content','')
 if title.startswith('Data:'):
  try:data=json.loads(text)
  except (ValueError,TypeError):continue
  if not isinstance(data,dict):continue
  typ='background' if title.startswith('Data:Backgrounds-') else 'action' if title.startswith('Data:Actions-') else 'feat-data' if title.startswith('Data:Feats-') else 'ancestry-trait' if title.startswith('Data:Traits-') else None
  if typ:add(data.get('原文'),data.get('中文'),p,typ,description=data.get('描述',''),traits=data.get('特征'),level=data.get('等级'))
  if title.startswith(('Data:Feats-','Data:Spells-','Data:Abilities-','Data:Actions-')):text='\n'.join(str(data.get(k) or '') for k in ['描述','特殊','相关'])
  else:continue
 family='embedded-data' if title.startswith('Data:') else 'class-page' if '{{职业信息' in text else 'ancestry-page' if '{{族裔信息' in text or title.endswith('族裔') else 'other'
 m=re.search(r'\|中文\s*=([^\n]+).*?\|原文\s*=([^\n]+)',text,re.S)
 if m and family!='other':add(plain(m[2]),plain(m[1]),p,{'class-page':'class','ancestry-page':'ancestry'}[family],description=text,context=family)
 parts=[]
 for line in text.splitlines():
  if line.startswith('{{CR|'):parts.append((text.find(line),line.split('|',2)[-1].rstrip('}')))
 for match in re.finditer(r'^(?:=+[^\n]+?=+|\|能力\d+=[^\n]+|\|标题=[^\n]+)',text,re.M):parts.append((match.start(),match.group()))
 for match in re.finditer(r"'''([^'\n]{1,180})'''|<(?:b|strong)>([^<\n]{1,180})</(?:b|strong)>|\[b\]([^\n]{1,180}?)\[/b\]",text,re.I):parts.append((match.start(),next(s for s in match.groups() if s)))
 for pos,raw in parts:
  label=plain(re.sub(r'^\|(?:能力\d+|标题)=','',raw));label=re.sub(r'\s*\d+\s*级\s*$','',label).strip()
  if len(label)>200 or not re.search('[A-Za-z]',label) or not re.search('[\u3400-\u9fff]',label):continue
  end=text.find('\n===',pos+len(raw));end=end if end>=0 else min(len(text),pos+3000)
  pair=re.fullmatch(r'(.+[\u3400-\u9fff])\s*([A-Za-z0-9\u00c0-\u024f][A-Za-z0-9\u00c0-\u024f \'’+&:.,!()/-]*)',label)
  if pair:add(pair[2],pair[1].strip(' ：:/|-'),p,'bilingual-heading',context=family,raw=raw,description=text[pos:end])
  headers.append({'label':label,'page':title,'revid':p['revid'],'context':family,'raw':raw,'description':text[pos:end]})
for row in rows:
 en=clean(row['en'])
 for h in headers:
  label=h['label'];cl=label.casefold();suffix=en.casefold()
  if cl.endswith(suffix):
   zh=label[:-len(en)].strip(' ：:/|-')
   if re.search('[\u3400-\u9fff]',zh) and not re.search(r'[A-Za-z][A-Za-z0-9 -]*$',zh):add(row['en'],zh,pages[h['page']],'bilingual-heading',context=h['context'],raw=h['raw'],description=h['description'])
idx=defaultdict(list)
for r in records:idx[key(r['en'])].append(r)
gloss=defaultdict(list)
for en,vs in j(W/'source-cache/terminology-index.json').items():
 for v in vs:gloss[key(en)].append(v)
for r in rows:
 candidates=idx[key(r['en'])];kind=r['kind']
 exact=[a for a in candidates if a['kind']==kind]
 headings=[a for a in candidates if a['kind']=='bilingual-heading' and ((kind in ['class-feature'] and a.get('context')=='class-page') or (kind in ['heritage','ancestry-feature'] and a.get('context')=='ancestry-page') or kind=='action')]
 wiki=exact or headings
 if not wiki and kind=='ancestry':wiki=[a for a in candidates if a['kind']=='ancestry-trait'] or [a for a in candidates if a['kind']=='bilingual-heading' and a.get('context')=='ancestry-page']
 if not wiki and kind in ['class-feature','ancestry-feature','heritage']:wiki=[a for a in candidates if a['kind']=='bilingual-heading']
 if not wiki and kind in ['class-feature','ancestry-feature']:wiki=[a for a in candidates if a['kind']=='feat-data']
 g=[{'en':r['en'],'zh':a['zh'],'page':'用户译名表','row':a.get('row'),'notes':a.get('notes')} for a in gloss[key(r['en'])]]
 options=wiki or g;names=sorted({a['zh'] for a in options});target=names[0] if len(names)==1 else None
 status='consistent' if target and zk(target)==zk(r['current']) else 'different' if target else 'conflicting' if options else 'unmatched'
 r.update({'proposed':target,'status':status,'method':'Wiki-exact-name-context' if wiki else 'glossary-fallback' if g else 'none','candidates':options,'glossary':g})
 if not options:
  near=[]
  for k in difflib.get_close_matches(key(r['en']),list(idx),n=3,cutoff=.74):near.extend(idx[k][:2])
  r['fuzzy']=near
(D/'name-records.json').write_bytes(json.dumps(records,ensure_ascii=False,indent=2).encode('utf-8'))
(D/'catalogue.json').write_bytes(json.dumps(rows,ensure_ascii=False,indent=2).encode('utf-8'))
print('SCOPE',len(rows),'RECORDS',len(records),'STATUS',Counter((r['kind'],r['status']) for r in rows))
for r in rows:
 if r['status'] in ['different','conflicting']:print(r['kind'],r['en'],'|',r['current'],'=>',r['proposed'] or sorted({a['zh'] for a in r['candidates']}))
