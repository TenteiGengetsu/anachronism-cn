import difflib,html,json,re,unicodedata
from pathlib import Path
from collections import defaultdict,Counter
D=Path(__file__).resolve().parent;W=D.parent;R=W/'anachronism-cn'
def j(p):return json.loads(p.read_text('utf-8-sig'))
def norm(s):
 s=html.unescape(unicodedata.normalize('NFKC',str(s))).translate(str.maketrans({'’':"'",'‘':"'",'–':'-','—':'-','‑':'-'}))
 return re.sub(r'\s+',' ',''.join(c for c in s if unicodedata.category(c)!='Cf')).casefold().strip()
def key(s):return re.sub('[^a-z0-9+]','',norm(s))
def zk(s):return re.sub(r'[\W_]','',norm(s))
def stripen(s,en):
 if s.endswith(' '+en):return s[:-len(en)-1].rstrip()
 return s
live=j(D/'live-wiki.json');current={p['title'] for p in live['inventory']};pages=j(D/'all-wiki-pages.json');records=[]
for title,p in pages.items():
 if title not in current or p.get('missing'):continue
 try:data=json.loads(p['content'])
 except (ValueError,TypeError):continue
 if not isinstance(data,dict):continue
 kind='spell' if title.startswith('Data:Spells-') else 'feat' if title.startswith('Data:Feats-') else None
 if kind:
  en=data.get('原文');zh=data.get('中文')
  if isinstance(en,str) and isinstance(zh,str) and re.search('[\u3400-\u9fff]',zh):
   records.append({'en':en.strip(),'zh':zh.strip(),'kind':kind,'page':title,'revid':p['revid'],'description':data.get('描述',''),'category':data.get('专长分类',data.get('法术分类')),'traits':data.get('特征'),'level':data.get('等级',data.get('环级'))})
idx=defaultdict(list)
for r in records:idx[(r['kind'],key(r['en']))].append(r)
gloss=defaultdict(list)
for en,vs in j(W/'source-cache/terminology-index.json').items():
 for v in vs:gloss[key(en)].append(v)
original=j(W/'source-cache/repo-original-export.json');rows=[]
for category in ['spells','feats']:
 file='sf2e-anachronism.'+category+'.json';tr=j(R/'translations'/file)['entries'];kind={'spells':'spell','feats':'feat'}[category]
 for en,source in original[file]['entries'].items():
  id=source['_id'];cn=stripen(tr[id]['name'],en);g=gloss[key(en)];wiki=idx[(kind,key(en))]
  candidates=[{'en':en,'zh':v['zh'],'page':'用户译名表','row':v.get('row'),'notes':v.get('notes')} for v in g] if g else wiki
  names=sorted(set(c['zh'] for c in candidates));proposed=names[0] if len(names)==1 else None
  status='consistent' if proposed and zk(cn)==zk(proposed) else 'different' if proposed else 'conflicting' if candidates else 'unmatched'
  near=[]
  if not candidates:
   for match in difflib.get_close_matches(key(en),[k for t,k in idx if t==kind],n=3,cutoff=.72):near.extend(idx[(kind,match)])
  rows.append({'file':file,'id':id,'en':en,'current':cn,'proposed':proposed,'kind':kind,'category':source['system'].get('category'),'traits':source['system'].get('traits',{}).get('value'),'level':source['system'].get('level'),'status':status,'method':'glossary' if g else 'wiki-exact-normalized' if wiki else 'none','candidates':candidates,'wikiCandidates':wiki,'fuzzy':near,'sourceDescription':source['system']['description']['value']})
(D/'name-records.json').write_bytes(json.dumps(records,ensure_ascii=False,indent=2).encode('utf-8'))
(D/'catalogue.json').write_bytes(json.dumps(rows,ensure_ascii=False,indent=2).encode('utf-8'))
print('records',len(records),'scope',len(rows),'status',dict(Counter((r['kind'],r['status']) for r in rows)))
for r in rows:
 if r['status'] in ['different','conflicting']:print(r['kind'],r['id'],r['en'],'|',r['current'],'=>',r['proposed'] or sorted({c['zh'] for c in r['candidates']}))
