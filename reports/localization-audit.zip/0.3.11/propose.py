import copy,json,re,html,unicodedata
from pathlib import Path
from collections import defaultdict,Counter
from text_localization import macros,tag_tokens
D=Path(__file__).resolve().parent;W=D.parent;R=W/'anachronism-cn'
def j(p):return json.loads(p.read_text('utf-8-sig'))
def norm(s):return re.sub(r'\s+',' ',html.unescape(unicodedata.normalize('NFKC',str(s))).replace('’',"'")).casefold().strip()
original=j(W/'source-cache/repo-original-export.json');plan=j(D/'name-plan.json');groups=[]
for r in plan.values():
 groups.append({'en':r['en'],'aliases':list(set([r['en']]+r.get('EnglishAliases',[]))),'old':r['current'],'new':r['proposed'],'ids':[r['id']],'kind':r['kind']})
 for alias in r.get('additionalOldChinese',[]):groups.append({'en':r['en'],'aliases':[r['en']],'old':alias,'new':r['proposed'],'ids':[r['id']],'kind':r['kind']})
 if r.get('referenceBase'):
  b=r['referenceBase'];groups.append({'en':b['English'],'aliases':[b['English']],'old':b['oldChinese'],'new':b['Chinese'],'ids':[r['id']],'kind':r['kind']})
groups.append({'en':'River Between','aliases':['River Between'],'old':'星间之河','new':'交界河','ids':[],'kind':'proper-name-component','page':'Data:Feats-Ride the River Between.json','revid':10363})
related=[('Augmented','改造者','殖装狂','殖装狂变体',21701),('Shield Ace','盾牌王牌','盾牌精英','盾牌精英变体',21702)]
for en,old,new,page,rev in related:
 ids=[v['_id'] for f in original.values() for v in f['entries'].values() if isinstance(v,dict) and v.get('name')==en]
 groups.append({'en':en,'aliases':[en],'old':old,'new':new,'ids':ids,'kind':'archetype','namedMarkupOnly':True,'page':page,'revid':rev})
for g in groups:
 if g['en']=='Censormoji':g['aliases'].append('censoring emoji')
 for pack in original.values():
  for obj in pack['entries'].values():
   if not isinstance(obj,dict) or obj.get('type')!='effect':continue
   base=re.sub(r'^(?:Spell )?Effect: *','',obj.get('name',''),flags=re.I)
   if any(norm(base)==norm(a) for a in g['aliases']):g['ids'].append(obj['_id'])
(D/'replacement-groups.json').write_bytes(json.dumps(groups,ensure_ascii=False,indent=2).encode('utf-8'))
byold=defaultdict(list)
for g in groups:byold[g['old']].append(g)
cnpat=re.compile('|'.join(re.escape(k) for k in sorted(byold,key=len,reverse=True)))
tagpat=re.compile(r'(</?[A-Za-z][^>]*>|<!--.*?-->)',re.S)
def get(o,path):
 for part in path.split('.'):
  if isinstance(o,list):o=o[int(part)] if part.isdigit() and int(part)<len(o) else None
  elif isinstance(o,dict):o=o.get(part)
  else:return None
 return o
def englishmatch(text,en):return re.search(r'(?<![a-z0-9])'+re.escape(norm(en))+r'(?:s)?(?![a-z0-9])',norm(text)) is not None
def references(en,g):return any(re.search(r'Compendium\.sf2e-anachronism\.[A-Za-z0-9_-]+\.(?:Item\.|JournalEntry\.)?'+re.escape(id)+r'(?:\]|\b)',en) for id in g['ids'])
def eligible(en,g):
 if references(en,g):return True
 if g.get('namedMarkupOnly'):return norm(en).strip()==norm(g['en'])
 return any(englishmatch(en,a) for a in g['aliases'])
changes=[];held=[];updated={};allunits=[]
def edit(file,path,owner,field,old,en,src):
 assert isinstance(en,str),(file,path,'English unavailable')
 reasons=[];new=old
 if field=='name' and src.get('_id') in plan and norm(src.get('name'))==norm(plan[src['_id']]['en']):
  p=plan[src['_id']];new=p['proposed']+(' '+en if en in old else '');reasons.append('reviewed-primary-name')
 else:
  a=tagpat.split(old);b=tagpat.split(en);aligned=len(a)==len(b) and all(a[i]==b[i] for i in range(1,len(a),2))
  for i in range(0,len(a),2):
   english=b[i] if aligned else en
   def repl(m):
    candidates=[g for g in byold[m[0]] if eligible(english,g)]
    targets={g['new'] for g in candidates}
    if len(targets)==1:reasons.extend(g['en'] for g in candidates);return next(iter(targets))
    held.append({'file':file,'path':path,'old':m[0],'English':english,'Chinese':a[i],'reason':'ambiguous-target' if targets else 'no matching English or UUID in the text node'})
    return m[0]
   a[i]=cnpat.sub(repl,a[i])
  new=''.join(a)
 if new==old:return
 assert tag_tokens(old)==tag_tokens(new),(file,path,'HTML')
 assert [m['body'] for m in macros(old)]==[m['body'] for m in macros(new)],(file,path,'macro')
 assert re.findall(r'\d+(?:\.\d+)?',old)==re.findall(r'\d+(?:\.\d+)?',new),(file,path,'numbers')
 changes.append({'file':file,'path':path,'sourceName':src.get('name'),'sourceType':src.get('type'),'English':en,'old':old,'new':new,'reasons':sorted(set(reasons))});owner[field]=new

def collect_patch(file,patch,src,path):
 for field in ['name','description','content']:
  if field not in patch:continue
  p={'name':'name','description':'system.description.value','content':'text.content'}[field]
  en=get(src,p)
  if not isinstance(en,str):raise AssertionError((file,path,p))
  allunits.append((file,path+[field]));edit(file,path+[field],patch,field,patch[field],en,src)
 for field,patches in patch.items():
  if field in ['items','pages','subitems']:
   raw=src.get(field) if field!='subitems' else get(src,'system.subitems')
   assert isinstance(raw,list),(file,path,field)
   byid={s['_id']:s for s in raw}
   for i,p in enumerate(patches):
    item=byid[p['id']];assert item['name']==p['expectedName']
    collect_patch(file,p,item,path+[field,i])
  elif field=='extraFields':
   for i,p in enumerate(patches):
    en=get(src,p['path']);assert en==p['expected']
    edit(file,path+[field,i,'text'],p,'text',p['text'],en,src)
  elif field=='cnPrerequisites':
   for i,p in enumerate(patches):
    edit(file,path+[field,i,'text'],p,'text',p['text'],p['expected'],src)
  elif field.startswith('cnText_'):
   edit(file,path+[field,'text'],patches,'text',patches['text'],patches['expected'],src)
  elif field=='cnHolyModuleCorrection':
   edit(file,path+[field,'text'],patches,'text',patches['text'],patches['expectedDescription'],src)

for file,sourcepack in original.items():
 p=R/'translations'/file;tr=j(p);before=copy.deepcopy(tr)
 if not tr.get('mapping'):continue
 byid={s['_id']:s for s in sourcepack['entries'].values() if isinstance(s,dict)}
 for id,patch in tr['entries'].items():
  src=byid[id]
  if 'description' in patch and tr['mapping'].get('description')=='system.details.publicNotes':
   # Actor public notes have the same guarded text workflow, a different source path.
   edit(file,['entries',id,'description'],patch,'description',patch['description'],get(src,'system.details.publicNotes'),src)
   tmp={k:v for k,v in patch.items() if k!='description'};collect_patch(file,tmp,src,['entries',id]);patch.update(tmp)
  else:collect_patch(file,patch,src,['entries',id])
 if tr!=before:updated[file]=tr


(D/'proposed-translations').mkdir(exist_ok=True)
for file,data in updated.items():(D/'proposed-translations'/file).write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
(D/'proposals.json').write_bytes(json.dumps(changes,ensure_ascii=False,indent=2).encode('utf-8'))
(D/'held-references.json').write_bytes(json.dumps(held,ensure_ascii=False,indent=2).encode('utf-8'))
units=[];seen=set()
for c in changes:
 a=tagpat.split(c['old']);b=tagpat.split(c['new']);e=tagpat.split(c['English'])
 if len(a)!=len(b) or len(a)!=len(e):a=[c['old']];b=[c['new']];e=[c['English']]
 for x,y,z in zip(a,b,e):
  if x==y:continue
  sig=(z,x,y)
  if sig in seen:continue
  seen.add(sig);units.append({**{k:c[k] for k in ['file','path','sourceName','sourceType']},'English':z,'old':x,'new':y})
(D/'review-units.json').write_bytes(json.dumps(units,ensure_ascii=False,indent=2).encode('utf-8'))
print('FIELDS',len(changes),'PACKS',dict(Counter(c['file'] for c in changes)),'KINDS',dict(Counter(c['path'][-1] for c in changes)),'HELD',len(held),'UNIQUE UNITS',len(units))
