import copy,json,re
from pathlib import Path
from collections import Counter
D=Path(__file__).resolve().parent
def j(p):return json.loads(p.read_text('utf-8-sig'))
def key(s):return re.sub('[^a-z0-9+]','',s.casefold())
rows=j(D/'catalogue.json');records=j(D/'name-records.json');by={r['en']:r for r in rows};pages=j(D/'all-wiki-pages.json')
aliases={'Philosophical Damnation':'Philosphical Damnation','Peacekeeper’s Armory':"Peackeeper's Armory",'Labyrinthine Mind':'Labyrintine Mind','Advanced Atmospheric Flight':'Advance Atmospheric Flight','Gnarefuroid Lore':'Ganerefuroid Lore','Breach':'Breech','Just Like Rehearsal':'Just Like Rehersal','Menacing Men':'Menacing Mien','Decorated Peacekeeper':'Decorated Peackeeper',"Death's Indifference":"Death's Indifferencce",'Unlucky for Some':'Unluckky For Some','Chemical Connoisseur':'Chemical Connoissuer','Empathic Pulse':'Emapthic Pulse','Knight of Golarion Dedication':'Knight of Golarian Dedication','Gigafuroid Form':'Gigfuroid Form','Pheromone Connection':'Pheremone Connection','Broad Shoulders':'Braod Shoulders','Heart of Planets Lost':'Heart of the Planets Lost','Refresh Cirrisensors':'Refersh Cirrisensors','Termorsense':'Tremorsense'}
for en,alias in aliases.items():
 row=by[en];hits=[r for r in records if r['kind']==row['kind'] and key(r['en'])==key(alias)];assert len(hits)==1,(en,hits)
 row.update({'candidates':hits,'method':'reviewed-spelling-alias-and-rule-context','EnglishAliases':[alias]})
 row['proposed']=hits[0]['zh'].replace('（专长）','') if en=='Termorsense' else hits[0]['zh']
 if en=='Termorsense':row['glossaryEnglish']='Tremorsense'
for en,root,suffix,mode in [('Widest Field of View (Phasorq)','Widest Field Of View','（双相人）','same-ancestry-and-rule'),('Widest Field of View (Izalguun)','Widest Field Of View','（伊扎尔贡人）','shared-English-root-and-all-around-vision-component-only'),('Stretching Reach (Nuar)','Stretching Reach','（牛尔人）','same-rule-with-retained-ancestry-qualifier'),('Gooey Engulf (Entu)','Gooey Engulf','（因图菌群）','same-rule-and-included-ancestry'),('Ancestral Weapon Familiarity (Astrazoan)','Ancestral Weapon Familiarity','（星蛸族）','standard-weapon-familiarity-term-component-only')]:
 row=by[en];hit=next(r for r in records if r['kind']=='feat' and key(r['en'])==key(root));row.update({'candidates':[hit],'method':mode,'proposed':hit['zh']+suffix,'referenceBase':{'English':root,'Chinese':hit['zh'],'oldChinese':row['current'].split('（')[0]}})
for en in ['Awaken Computer','Forge Drift Beacon']:
 p=pages['Data:Rituals-'+en+'.json'];v=json.loads(p['content']);by[en].update({'candidates':[{'en':en,'zh':v['中文'],'page':p['title'],'revid':p['revid'],'kind':'ritual','description':v.get('描述','')}],'method':'ritual-data-exact-name','proposed':v['中文']})
p=pages['《虫群之秘》'];assert '同心（Singlemind）' in p['content'];by['Singlemind'].update({'candidates':[{'en':'Singlemind','zh':'同心','page':p['title'],'revid':p['revid'],'kind':'ritual-catalogue','description':'====仪式====\n同心（Singlemind）'}],'method':'explicit-bilingual-ritual-title-in-same-publication','proposed':'同心'})
p=pages['时移冒险'];assert '制造师（Fabricator）' in p['content'];by['Fabricator'].update({'candidates':[{'en':'Fabricator','zh':'制造师','page':p['title'],'revid':p['revid'],'kind':'explicit-bilingual-reference','description':'制造师（Fabricator）技能专长允许PC用创造胶囊（creator capsules）在数小时内3D打印装备'}],'method':'explicit-bilingual-skill-feat-reference-and-same-Crafting-rule','proposed':'制造师','additionalOldChinese':['制造者']})
for en,extra in [('Anti-Glitch Response',['故障应对']),('GG-OS Frame',['GG-OS机体'])]:by[en]['additionalOldChinese']=extra
# The glossary entry is a religion; this feat manifests the center of a black hole.
s=by['Singularity'];s['rejectedCandidates']=s['candidates'];s.update({'candidates':s['wikiCandidates'],'proposed':'奇点','method':'Wiki-same-solarian-feat-glossary-homonym-rejected','note':'词表A1141描述信仰纯一主义，不能用于恒星武士黑洞奇点专长。'})
by['Ride the River Between'].update({'proposed':'乘骑交界河','method':'Wiki-name-priority-confirmed-by-user','note':'用户本轮明确：名称尽量以Wiki为准；词表River Between旧译星间之河，按Wiki统一为交界河。'})
p=by['Prehensile Tail'];p.update({'candidates':p['wikiCandidates'],'proposed':'盘卷尾巴','method':'Wiki-name-priority-confirmed-by-user','note':'用户本轮明确名称优先Wiki；词表抓握尾改按Wiki盘卷尾巴。','additionalOldChinese':['抓握尾巴']})
for row in rows:
 row['status']='consistent' if row['current']==row['proposed'] else 'different' if row['proposed'] else 'unmatched'
 if row['en']=='Fire Crystal Beam':row.update({'note':'用户确认仅名称差异优先Wiki，名称改为火晶射线；正文10d6力场伤害、传送及原有自动化均不改动。'})
 if row['en']=='Root Access (SRO)':row['note']='未与科技法师20级同名专长Root Access强行归并；角色规则与所指不同。'

plan={r['id']:r for r in rows if r['status']=='different'}
(D/'aligned-catalogue.json').write_bytes(json.dumps(rows,ensure_ascii=False,indent=2).encode('utf-8'))
(D/'name-plan.json').write_bytes(json.dumps(plan,ensure_ascii=False,indent=2).encode('utf-8'))
print('STATUS',Counter((r['kind'],r['status']) for r in rows),'CHANGES',len(plan))
for r in plan.values():print(r['en'],'|',r['current'],'=>',r['proposed'])
