import json,re,hashlib,zipfile,shutil,subprocess
from pathlib import Path
from collections import Counter
from text_localization import macros,tag_tokens
D=Path(__file__).resolve().parent;W=D.parent;R=W/'anachronism-cn';O=W.parent/'outputs'
def j(p):return json.loads(p.read_text('utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,obj):
 b=(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
 if p.exists() and b'\r\n' in p.read_bytes():b=b.replace(b'\n',b'\r\n')
 p.write_bytes(b)
def key(s):return re.sub('[^a-z0-9+]','',s.casefold())
before=j(D/'baseline-expected-export.json');after=j(D/'repo-expected-export.json');changes=j(D/'proposals.json');display=j(D/'display-proposals.json');plan=j(D/'name-plan.json');rows=j(D/'aligned-catalogue.json');diffs=[]
def compare(a,b,path):
 assert type(a)==type(b),(path,'type')
 if isinstance(a,dict):
  assert a.keys()==b.keys(),(path,'keys')
  for k in a:compare(a[k],b[k],path+[k])
 elif isinstance(a,list):
  assert len(a)==len(b),(path,'array')
  for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+[i])
 elif a!=b:
  assert isinstance(a,str) and re.search('[\u3400-\u9fff]',a),(path,'non-display data')
  joined='.'.join(map(str,path))
  assert path[-1] in ['name','label'] or re.search(r'\.system\.(?:description\.value|requirements|prerequisites\.value\.\d+\.value)$',joined) or joined.endswith('.text.content'),(path,'outside display paths')
  assert tag_tokens(a)==tag_tokens(b),(path,'HTML')
  assert [m['body'] for m in macros(a)]==[m['body'] for m in macros(b)],(path,'macro/UUID')
  assert re.findall(r'\d+(?:\.\d+)?',a)==re.findall(r'\d+(?:\.\d+)?',b),(path,'numbers')
  diffs.append({'path':path,'old':a,'new':b})
compare(before,after,[])
assert len(diffs)==len(changes)==233
assert Counter((c['old'],c['new']) for c in changes)==Counter((c['old'],c['new']) for c in diffs)
with zipfile.ZipFile(D/'baseline.zip') as z:
 oldvalidation=z.read('reports/validation.json');basev=json.loads(oldvalidation);termlines=z.read('reports/terms.tsv').decode('utf-8-sig').splitlines();expected=z.read('scripts/display-strings.mjs')
 for c in display:expected=expected.replace(json.dumps(c['old'],ensure_ascii=False).encode('utf-8'),json.dumps(c['new'],ensure_ascii=False).encode('utf-8'))
 assert expected==(R/'scripts/display-strings.mjs').read_bytes(),'display module changed outside reviewed literal values'
 for n in ['scripts/register.mjs','scripts/display.mjs','tools/source-names.json','README.md']:
  assert z.read(n)==(R/n).read_bytes(),n
assert before['sf2e-anachronism.feats.json']['entries']['Fire Crystal Beam']['system']['description']==after['sf2e-anachronism.feats.json']['entries']['Fire Crystal Beam']['system']['description']
assert '10d6' in after['sf2e-anachronism.feats.json']['entries']['Fire Crystal Beam']['system']['description']['value']
source=j(W/'source-cache/repo-original-export.json');titles=j(R/'translations/titles.json');queries={}
for id,c in plan.items():
 displayname=c['proposed']+' '+c['en'];entry=j(R/'translations'/c['file'])['entries'][id]
 assert entry['name']==displayname,(id,displayname)
 collection=c['file'].removesuffix('.json');assert titles[collection]['titles'][id]==displayname and titles[collection]['titles'][c['en']]==displayname
 hits=[v['_id'] for en,v in source[c['file']]['entries'].items() if c['proposed'] in titles[collection]['titles'][v['_id']]]
 assert id in hits;queries[c['en']]={'Chinese':c['proposed'],'ids':hits}
 assert source[c['file']]['entries'][c['en']]['system']['slug']
assert len(plan)==135 and len(display)==11
master={key(en):(cn,en) for cn,en in (l.split('\t') for l in termlines)};assert len(master)==795
with zipfile.ZipFile(W.parent/'archives/terminology-review-2026-10-24.zip') as z:oldterms=json.loads(z.read('final-audit.json'))
classes={key(d['English']):d['decision'] for d in oldterms['decisions'] if d['decision'].startswith('retain-')}
for f in [O/'恒星武士水晶修订译名.tsv',R/'reports/equipment-term-corrections.tsv']:
 for line in f.read_text('utf-8-sig').splitlines():classes[key(line.split('\t')[1])]='retain-correction'
assert Counter(classes[k] for k in master)==Counter({'retain-new':700,'retain-correction':95})
pairs={key(r.get('glossaryEnglish',r['en'])):(r['proposed'],r.get('glossaryEnglish',r['en'])) for r in plan.values()}
pairs[key('River Between')]=('交界河','River Between');assert len(pairs)==136
for k,pair in pairs.items():master[k]=pair;classes[k]='retain-correction'
terms=''.join(cn+'\t'+en+'\n' for cn,en in sorted(master.values(),key=lambda p:p[1].casefold()))
wave=''.join(cn+'\t'+en+'\n' for cn,en in sorted(pairs.values(),key=lambda p:p[1].casefold()))
for f in [R/'reports/terms.tsv',O/'新增及修订译名汇总.tsv']:f.write_bytes(terms.encode('utf-8'))
for f in [R/'reports/spell-feat-term-corrections.tsv',O/'法术专长修订译名.tsv']:f.write_bytes(wave.encode('utf-8'))
counts=Counter(classes[k] for k in master)
notes='''本次核对 231 个法术／仪式及 2,199 个专长的名称与显示引用，并非全量规则正文的逐句重译。

名称差异优先采用 SF2 Wiki；内容差异保留模组版本，另行说明。实际修订 60 个法术／仪式、75 个专长，以及交界河这一专名；本轮对照表共136行，不把效果名、子选项或重复引用另算新译名。

核对中保留的内容差异与版本语境：
1. Fire Crystal Beam 名称按 Wiki 改为火晶射线。模组原文和 Wiki 正文均为力场伤害；模组现有10d6力场伤害、传送和豁免自动化全部保留。名称不用于推断火焰伤害。
2. Widest Field of View (Izalguun) 名称词干统一为极宽视野，并保留伊扎尔贡人后缀。其模组原文额外允许同时向两个方向搜索；Wiki 双相人版本未列此项。仅统一共享名称，保留各族裔版本的规则。
3. Ancestral Weapon Familiarity (Astrazoan) 名称统一使用武器熟稔。模组星蛸族版本获得另一族裔／传承的武器熟稔专长；Wiki 通用版本描述本族裔武器。保留模组星蛸族规则，不用通用版本覆盖。
4. 模组拼写 Termorsense 的专长名称改为震颤感知；对照表按标准拼写 Tremorsense 汇总，运行条目仍保留模组英文和ID。模组奥德版本的开场文字描述没有眼睛，Wiki 合并条目包含卓克斯虫人语境的双眼描述；保留模组版本。30尺模糊感官规则未改。
5. Unlucky for Some 名称改为灾厄转嫁。模组原文赋予反应24小时或直到下次使用为止，Wiki 描述未写出后一个截止条件；当前译文保留模组的完整条件。
6. 词表 Singularity 的纯一主义指一种信仰；恒星武士专长对应黑洞奇点，按 Wiki 保留奇点，不混用同名信仰条目。

另外318个专长未确认完整标题的可靠对应，保留当前译名；其中包含有独立规则的同名族裔版本。这不代表Wiki不存在中文。已按当前Data、主命名空间页面清单、拼写变体、双语正文引用和关联词进行补查，完整定位见项目核对报告。

资料访问：配置中的灰机MCP指向PF2；SF2公开网页接口返回403。本次使用已有的SF2只读API客户端，更新2,719页源码并记录页面修订号，没有改动Wiki或原始译名表。
验证：Babele2.9.1原生全量转换5616条通过；按需和原生索引5613个名称通过。相对0.3.10，仅已复核的名称、描述内显示引用、前置条件、显示标签和11个界面字典值发生变化，规则数值、条件、公式、UUID、ID及slug保持。既有商用型圣洁模组2d4修正沿用。未新增真实Foundry会话测试。
'''
for f in [R/'reports/spell-feat-audit-notes.txt',O/'法术专长核对说明.txt']:f.write_bytes(notes.encode('utf-8'))
decisions=[]
for row in rows:
 obj={k:row[k] for k in ['file','id','en','current','proposed','kind','status','method']};obj['changed']=row['id'] in plan
 obj['authorities']=[{k:a[k] for k in ['en','zh','page','revid','row','notes','kind'] if k in a} for a in row['candidates']]
 if row.get('note'):obj['note']=row['note']
 if row['status']=='unmatched':obj['note']='未确认完整标题的可靠对应；保留当前译名，未按近似名称跨规则归并。'
 if row.get('EnglishAliases'):obj['EnglishAliases']=row['EnglishAliases']
 decisions.append(obj)
report={'version':'0.3.11','baselineVersion':'0.3.10','scope':{'spellsAndRituals':231,'feats':2199},'statusCounts':{kind:dict(Counter(x['status'] for x in rows if x['kind']==kind)) for kind in ['spell','feat']},'primaryNamesCorrected':135,'correctedSpellsAndRituals':60,'correctedFeats':75,'translationDisplayFields':len(changes),'interfaceDictionaryValues':len(display),'displayFieldsChanged':len(changes)+len(display),'namingPolicy':'User confirmed Wiki-first naming; module rule differences retained and documented.','sourceAccess':{'site':'https://sf2.huijiwiki.com','method':'Local read-only Huiji API client; configured MCP points to PF2; public SF2 fetch403','currentNamespaceInventoryPages':9191,'pagesRefreshed':2719,'originalGlossaryRows':1493},'reviewScope':j(D/'review-complete.json')['scope'],'reviewedUnits':227+len(display),'reviewPasses':['English identity and faithfulness comparison','Second English terminology/context comparison','Independent Chinese reading'],'mechanicalDataUnchangedFrom0310':True,'uuidMacroBodiesIdsSlugsNumbersUnchanged':True,'displayLogicAndRegistrationUnchanged':True,'displayDictionaryChangedOnlyReviewedLiteralValues':True,'terminology':{'wavePairs':len(pairs),'masterPairs':len(master),'newPairs':counts['retain-new'],'actualCorrectionPairs':counts['retain-correction'],'masterSha256':sha(terms.encode('utf-8')),'format':'Chinese TAB English; no heading, notes or extra columns; one normalized English key per line'},'contentDifferenceNotes':'reports/spell-feat-audit-notes.txt','decisions':decisions,'changes':changes,'displayDictionaryChanges':display}
save(R/'reports/spell-feat-name-audit-0.3.11.json',report);save(D/'baseline-scalar-diff.json',diffs)
save(R/'reports/search-index-validation-0.3.11.json',{'version':'0.3.11','primaryNamesAudited':2430,'changedNamesChecked':135,'allChineseQueriesAndEnglishAliasesPassed':True,'allStableIdsPreserved':True,'queries':queries,'nativeAndOndemandIndex':j(D/'validation.json'),'liveFoundryTested':False})
v=basev.copy();v['previousMaintenanceUpdate']={'version':'0.3.10','record':basev['maintenanceUpdate']};v.update(j(D/'0311-validation.json'))
v['historicalValidationSnapshot']='reports/localization-audit.zip:0.3.11/baseline-validation-0.3.10.json';v['translationOutputHashes']={p.name:sha(p.read_bytes()) for p in sorted((R/'translations').glob('sf*.json'))};v['searchIndexOutputHashes']={n:sha((R/'translations'/n).read_bytes()) for n in ['titles.json','labels.json']};v['displayStringsSha256']=sha((R/'scripts/display-strings.mjs').read_bytes());v['searchIndexCompatibility']=j(D/'validation.json');v['maintenanceUpdate']={k:report[k] for k in ['baselineVersion','scope','primaryNamesCorrected','correctedSpellsAndRituals','correctedFeats','translationDisplayFields','interfaceDictionaryValues','displayFieldsChanged','namingPolicy','terminology']};v['maintenanceUpdate'].update({'report':'reports/spell-feat-name-audit-0.3.11.json','searchReport':'reports/search-index-validation-0.3.11.json','mechanicalDataUnchangedFromBaseline':True,'runtimeLogicUnchanged':True})
assert v['runtimeScriptSha256']==sha((R/'scripts/register.mjs').read_bytes());assert v['displayScriptSha256']==sha((R/'scripts/display.mjs').read_bytes());save(R/'reports/validation.json',v)
m=j(R/'module.json');m['version']='0.3.11';m['download']=m['download'].replace('/v0.3.10/','/v0.3.11/');(R/'module.json').write_bytes((json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
archive=R/'reports/localization-audit.zip';temp=D/'localization-audit-new.zip'
with zipfile.ZipFile(archive) as old,zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for info in old.infolist():
  if not info.filename.startswith('0.3.11/'):z.writestr(info,old.read(info.filename))
 z.writestr('0.3.11/baseline-validation-0.3.10.json',oldvalidation)
 for n in ['live-wiki.json','unmatched-body-evidence.json','catalogue.json','aligned-catalogue.json','name-plan.json','proposals.json','held-references.json','review-complete.json','replacement-groups.json','display-proposals.json','0311-validation.json','validation.json','baseline-scalar-diff.json','catalogue.py','align.py','propose.py','propose-display.mjs','finish.py','test-indexes.mjs','validate.mjs']:
  z.write(D/n,'0.3.11/'+n)
assert zipfile.ZipFile(temp).testzip() is None;shutil.copyfile(temp,archive)
hashes={p.name:sha(p.read_bytes()) for p in (R/'translations').glob('*.json')};subprocess.run(['python','-X','utf8',str(R/'tools/build_search_indexes.py')],check=True,capture_output=True);assert hashes=={p.name:sha(p.read_bytes()) for p in (R/'translations').glob('*.json')}
files=[]
for n in ['module.json','coverage.json','scripts','translations','README.md','THIRD-PARTY-NOTICES.md','licenses','reports']:
 p=R/n;files.extend([p] if p.is_file() else sorted(x for x in p.rglob('*') if x.is_file()))
target=O/'anachronism-cn-0.3.11.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None;assert set(z.namelist())=={p.relative_to(R).as_posix() for p in files}
 for p in files:assert z.read(p.relative_to(R).as_posix())==p.read_bytes(),str(p)
shutil.copyfile(target,R/'dist/anachronism-cn.zip')
summary={'version':'0.3.11','packageFiles':len(files),'packageSha256':sha(target.read_bytes()),'packageBytes':target.stat().st_size,'archiveMatchesRepositoryBytes':True,'indexBuilderIdempotent':True,'automationAndSourceIdentityPreserved':True,'displayLogicUnchanged':True,'displayDictionaryValuesChanged':len(display),'primaryNamesCorrected':135,'displayFieldsChanged':len(changes)+len(display),'waveTermPairs':len(pairs),'masterTermPairs':len(master),'masterNewPairs':counts['retain-new'],'masterCorrectionPairs':counts['retain-correction'],'published':False}
save(D/'delivery-validation.json',summary);print(json.dumps(summary,ensure_ascii=False))
