"""Conservative text alignment: preserve source markup, never rewrite a rule object."""
import collections
import html
import json
import re
from pathlib import Path

WORK = Path(__file__).resolve().parent


def norm(s):
    import unicodedata
    return unicodedata.normalize('NFKC', s).replace('’', "'").replace('‘', "'").strip().casefold()


def macros(text):
    result = []
    i = 0
    while i < len(text):
        found = re.search(r'@[A-Za-z][\w-]*\[|\[\[', text[i:])
        if not found:
            break
        start = i + found.start()
        opening = text.find('[', start)
        depth = 0
        j = opening
        while j < len(text):
            if text[j] == '[':
                depth += 1
            elif text[j] == ']':
                depth -= 1
                if depth == 0:
                    break
            j += 1
        if j >= len(text):
            raise ValueError('Unclosed macro')
        end = j + 1
        display_end = end
        label = None
        if end < len(text) and text[end] == '{':
            close = text.find('}', end + 1)
            if close != -1:
                label = text[end + 1:close]
                display_end = close + 1
        result.append({'start': start, 'end': end, 'displayEnd': display_end, 'body': text[start:end], 'label': label})
        i = display_end
    return result


def tag_tokens(text):
    return re.findall(r'<!--.*?-->|</?[A-Za-z][^>]*>', text, re.S)


def strip_macros(text):
    for m in reversed(macros(text)):
        text = text[:m['start']] + text[m['displayEnd']:]
    return text


def plain_wiki(text):
    if not isinstance(text, str):
        return ''
    text = re.sub(r'<!--.*?-->', '', text, flags=re.S)
    text = re.sub(r'\[\[([^\[\]]+)\]\]', lambda m: m[1].split('|')[-1].split('#')[0], text)
    text = re.sub(r'\{\{浮窗\|[^{}|]+\|([^{}]+)\}\}', lambda m: m[1].split('|')[-1], text)
    text = re.sub(r'\{\{act\|([^{}]+)\}\}', lambda m: m[1], text, flags=re.I)
    text = re.sub(r"'{2,5}", '', text)
    text = re.sub(r'<br\s*/?>', '\n', text, flags=re.I)
    text = re.sub(r'</?p[^>]*>', '\n', text)
    text = re.sub(r'</?(?:b|strong|i|em|small|span)[^>]*>', '', text)
    if '{{' in text or '}}' in text or '<' in text or '{|' in text or '|}' in text:
        raise ValueError('Unresolved Wiki markup')
    text = re.sub(r'^\s*[*#:]+\s*', '', text, flags=re.M)
    return html.unescape(text).strip()


CONDITIONS = {'Clumsy':'笨拙','Drained':'流失','Enfeebled':'力竭','Stupefied':'呆滞','Sickened':'恶心','Frightened':'惊惧','Encumbered':'超载','Fatigued':'疲乏','Off-Guard':'措手不及','Blinded':'目盲','Dazzled':'目眩','Deafened':'耳聋','Observed':'可见','Concealed':'隐蔽','Hidden':'藏匿','Invisible':'隐形','Undetected':'无踪','Unnoticed':'未发现','Unconscious':'失去意识','Doomed':'毁灭','Wounded':'受伤','Dying':'濒死','Hostile':'敌对','Unfriendly':'不友善','Indifferent':'不关心','Friendly':'友善','Helpful':'乐于帮助','Grabbed':'受擒','Immobilized':'禁足','Prone':'倒地','Restrained':'束缚','Paralyzed':'麻痹','Petrified':'石化','Slowed':'缓慢','Stunned':'震慑','Quickened':'迅捷','Broken':'破损','Confused':'困惑','Controlled':'被控制','Fascinated':'迷魂','Fleeing':'逃跑'}
BASE_ACTIONS = {'Recall Knowledge':'回忆知识','Strike':'打击','Step':'跨步','Stride':'行走','Leap':'跳跃','Fly':'飞行','Swim':'游泳','Climb':'攀爬','Sneak':'潜行','Hide':'躲藏','Seek':'搜索','Demoralize':'威吓','Escape':'脱逃','Raise a Shield':'举盾','Take Cover':'寻找掩护','Sustain':'维持','Cast a Spell':'施法','Interact':'交互','Treat Wounds':'治疗伤势'}
SKILLS = {'acrobatics':'特技','arcana':'奥法','athletics':'运动','computers':'计算机','crafting':'手艺','deception':'欺骗','diplomacy':'交涉','intimidation':'威吓','medicine':'医疗','nature':'自然','occultism':'神秘','performance':'表演','piloting':'驾驶','religion':'宗教','society':'社会','stealth':'隐秘','survival':'生存','thievery':'贼活','fortitude':'强韧','reflex':'反射','will':'意志','perception':'察觉'}


class TextAligner:
    def __init__(self, entries, corpus):
        self.names = collections.defaultdict(set)
        for e in entries:
            if e.get('nameZh'):
                self.names[norm(e['name'])].add(e['nameZh'])
            if e.get('wikiMatch'):
                d = e['wikiMatch']['record']['data']
                self.names[norm(d['原文'])].add(d['中文'])
        records = json.loads((WORK / 'wiki-records.json').read_text(encoding='utf8'))
        for r in records:
            d = r['data']
            self.names[norm(d['原文'])].add(d['中文'])
            for v in d.get('类型数据', []):
                if v.get('类型名称') and v.get('类型'):
                    self.names[norm(v['类型名称'])].add(v['类型'])
        terms = json.loads((WORK / 'terminology-index.json').read_text(encoding='utf8'))
        for en, candidates in terms.items():
            zs = {x['zh'] for x in candidates}
            if len(zs) == 1:
                self.names[en] = zs
        for en, zh in {**CONDITIONS, **BASE_ACTIONS}.items():
            self.names[norm(en)].add(zh)
        self.doc_names = collections.defaultdict(set)
        for pack in corpus.values():
            for d in pack.values():
                if d.get('_id') and d.get('name'):
                    self.doc_names[d['_id']].add(d['name'])

    def aliases(self, m):
        result = set()
        labels = []
        if m['label']:
            labels.append(m['label'])
        if m['body'].startswith('@UUID['):
            doc_id = m['body'][:-1].split('.')[-1]
            labels += list(self.doc_names.get(doc_id, []))
        for label in labels:
            result |= self.names.get(norm(label), set())
            numeric = re.match(r'^(.*?) (\d+)$', label)
            if numeric:
                result |= {x + ' ' + numeric[2] for x in self.names.get(norm(numeric[1]), set())}
                result |= {x + numeric[2] for x in self.names.get(norm(numeric[1]), set())}
        return result

    def embed(self, original, translated):
        ms = macros(original)
        zh = translated
        placeholders = []
        cursor = 0
        for i, m in enumerate(ms):
            body = m['body']
            options = []
            if body.startswith('@UUID['):
                for alias in sorted(self.aliases(m), key=len, reverse=True):
                    start = zh.find(alias, cursor)
                    if start >= 0:
                        options.append((start, start + len(alias)))
            elif body.startswith('@Check['):
                inside = body[len('@Check['):-1]
                skill = inside.split('|')[0].replace('type:', '')
                label = SKILLS.get(skill)
                if label:
                    noun = label + ('豁免' if skill in ['fortitude','reflex','will'] else '检定')
                    dc = re.search(r'(?:^|\|)dc:(\d+)', inside)
                    patterns = [re.escape(noun)] if not dc else [rf'(?:DC\s*{dc[1]}(?:的)?\s*{re.escape(noun)}|{re.escape(noun)}[（(]?\s*DC\s*{dc[1]}[）)]?)']
                    for pat in patterns:
                        match = re.search(pat, zh[cursor:])
                        if match:
                            options.append((cursor+match.start(), cursor+match.end()))
            elif body.startswith('@Template['):
                distance = re.search(r'(?:distance|size):(\d+)', body)
                shape = next((v for k,v in {'burst':'爆发','cone':'锥形','line':'线形','emanation':'涌散'}.items() if k in body), None)
                if distance and shape:
                    for pat in [rf'{distance[1]}\s*尺(?:半径)?(?:的)?\s*{shape}',rf'{shape}(?:范围)?[（(]?\s*{distance[1]}\s*尺[）)]?']:
                        match = re.search(pat, zh[cursor:])
                        if match:
                            options.append((cursor+match.start(), cursor+match.end()))
            # Damage, dynamic checks and nontrivial inline rolls require explicit reviewed alignment.
            if not options:
                raise ValueError('Unaligned macro: ' + body.split('[')[0])
            start, end = min(options, key=lambda x: (x[0], -(x[1]-x[0])))
            placeholder = f'⟦MACRO{i}⟧'
            rendered = body
            if m['label'] and body.startswith('@UUID['):
                state = re.match(r'^(.*?) (\d+)$', m['label'])
                if state and norm(state[1]) in {norm(x) for x in CONDITIONS}:
                    cn = next(v for k,v in CONDITIONS.items() if norm(k)==norm(state[1]))
                    rendered += '{' + cn + ' ' + m['label'] + '}'
            elif m['label']:
                rendered += '{' + m['label'] + '}'
            zh = zh[:start] + placeholder + zh[end:]
            cursor = start + len(placeholder)
            placeholders.append((placeholder, rendered))
        for placeholder, rendered in placeholders:
            zh = zh.replace(placeholder, rendered)
        if [x['body'] for x in macros(zh)] != [x['body'] for x in ms]:
            raise ValueError('Macro order changed')
        return zh

    def align_piece(self, original, wiki):
        zh = plain_wiki(wiki)
        if not zh:
            raise ValueError('No Chinese source')
        tags = tag_tokens(original)
        wrapper_start = wrapper_end = ''
        match = re.fullmatch(r'\s*(<(?:em|i)>)([\s\S]*)(</(?:em|i)>)\s*', original)
        if match:
            wrapper_start, original, wrapper_end = match.groups()
        if tag_tokens(original):
            # Preserve the source tags while accepting Wiki's equivalent inline emphasis.
            formatted = re.sub(r'\[\[([^\[\]]+)\]\]', lambda m:m[1].split('|')[-1].split('#')[0], wiki)
            formatted = re.sub(r'\{\{浮窗\|[^{}|]+\|([^{}]+)\}\}', lambda m:m[1].split('|')[-1], formatted)
            formatted = re.sub(r"'''(.*?)'''", r'<strong>\1</strong>', formatted, flags=re.S)
            formatted = re.sub(r"''(.*?)''", r'<em>\1</em>', formatted, flags=re.S)
            target_tags = tag_tokens(formatted)
            source_tags = tag_tokens(original)
            def signature(tag):
                tag = re.sub(r'\s[^>]*', '>', tag).lower()
                return tag.replace('<b>', '<strong>').replace('</b>', '</strong>').replace('<i>', '<em>').replace('</i>', '</em>')
            if target_tags and list(map(signature,target_tags)) == list(map(signature,source_tags)):
                tag_iter=iter(source_tags)
                zh = re.sub(r'<!--.*?-->|</?[A-Za-z][^>]*>', lambda _:next(tag_iter), formatted, flags=re.S).strip()
            else:
                raise ValueError('Inline formatting needs explicit alignment')
        result = self.embed(original, zh)
        original_numbers = re.findall(r'\d+(?:\.\d+)?', html.unescape(strip_macros(original)))
        result_numbers = re.findall(r'\d+(?:\.\d+)?', html.unescape(strip_macros(result)))
        if collections.Counter(original_numbers) != collections.Counter(result_numbers):
            raise ValueError('Visible numbers differ')
        result = wrapper_start + result + wrapper_end
        if tag_tokens(result) != tags:
            raise ValueError('HTML tags differ')
        return result


LABELS = {'Frequency':('频率','频率'), 'Trigger':('触发','触发'), 'Requirements':('需求','需求'), 'Requirement':('需求','需求'), 'Effect':('描述','效果'), 'Special':('特殊','特殊'), 'Activate':('启动','启动'), 'Activation':('启动','启动'), 'Critical':('重击','重击'), 'Critical Success':('大成功','大成功'), 'Success':('成功','成功'), 'Failure':('失败','失败'), 'Critical Failure':('大失败','大失败')}


def paragraph_candidates(description, data, variant=None):
    """Assign Chinese fields only where the source structural role is explicit."""
    ps = list(re.finditer(r'(<p(?:\s[^>]*)?>)([\s\S]*?)(</p>)', description))
    if not ps:
        return [], ['No paragraph structure']
    body = data.get('描述') or ''
    normal = []
    assigned = []
    issues = []
    levels = [v.get('等级') for v in data.get('类型数据', []) if isinstance(v.get('等级'), (int, float))]
    nonbase_variant = bool(variant and levels and variant.get('等级') != min(levels))
    for p in ps:
        inner = p[2]
        link_only = re.fullmatch(r'\s*@UUID\[[^\]]+\](?:\{[^}]*\})?\s*', inner)
        if link_only:
            # This is an existing navigation link, not another prose paragraph.
            continue
        head = re.match(r'^(\s*)<strong>([^<]+)</strong>([\s\S]*)$', inner)
        if head and head[2] in LABELS:
            key, label = LABELS[head[2]]
            value = (variant or {}).get(key)
            if not value and not nonbase_variant:
                value = data.get(key)
            if key == '描述' and re.search(r'<p[^>]*>\s*(?!<strong>)[^<\s]', description):
                # An item's shared description is not its activation's Effect text.
                value = data.get('效果')
            if value:
                assigned.append({'paragraph': p, 'original': head[3], 'wiki': value, 'prefix': head[1]+'<strong>'+label+'</strong>', 'field': key})
            else:
                issues.append('No Wiki field: ' + key)
        elif head and head[2].startswith('Heightened'):
            heightening = data.get('升阶') or ''
            if not isinstance(heightening, str):
                heightening = ''
            n = re.search(r'\d+', head[2])
            chunks = re.findall(r'<(?:b|strong)>(.*?)</(?:b|strong)>\s*([\s\S]*?)(?=<(?:b|strong)>|$)', heightening)
            matching = [(h, v) for h,v in chunks if n and re.search(r'(?<!\d)'+n[0]+r'(?!\d)', h)]
            if len(matching) == 1:
                h, v = matching[0]
                v = re.sub(r'<br\s*/?>\s*$', '', v).strip()
                assigned.append({'paragraph':p,'original':head[3],'wiki':v,'prefix':head[1]+'<strong>'+h+'</strong>','field':'升阶'})
            else:
                issues.append('Heightening needs alignment')
        else:
            normal.append(p)
    try:
        plain = plain_wiki(body)
    except ValueError:
        plain = ''
    if normal:
        if nonbase_variant:
            issues.append('Non-base model needs variant-specific prose')
        elif len(normal) == 1 and plain:
            assigned.append({'paragraph':normal[0],'original':normal[0][2],'wiki':body,'prefix':'','field':'描述'})
        else:
            chunks = [x.strip() for x in re.split(r'\n\s*\n', plain) if x.strip()]
            if len(chunks) != len(normal):
                chunks = [x.strip() for x in plain.splitlines() if x.strip()]
            if len(chunks) == len(normal):
                for p, chunk in zip(normal,chunks):
                    assigned.append({'paragraph':p,'original':p[2],'wiki':chunk,'prefix':'','field':'描述'})
            else:
                issues.append('Body paragraph count differs')
    if variant and variant.get('类型描述'):
        # Variant prose often supplies mechanics absent from the shared description.
        # Do not merge it into the family paragraph without reviewed alignment.
        issues.append('Variant prose requires alignment')
    return assigned, issues


def localize_description(description, match, aligner):
    data = match['record']['data']
    variant = match.get('variant')
    assigned, issues = paragraph_candidates(description, data, variant)
    replacements = []
    review = []
    for a in assigned:
        try:
            translated = aligner.align_piece(a['original'], a['wiki'])
        except ValueError as error:
            issues.append(str(error))
            continue
        p = a['paragraph']
        value = p[1] + a['prefix'] + translated + p[3]
        replacements.append((p.start(),p.end(),value))
        review.append({'field':a['field'],'en':a['original'],'zh':translated,'wiki':a['wiki']})
    result = description
    for start,end,value in sorted(replacements,reverse=True):
        result = result[:start]+value+result[end:]
    if tag_tokens(result) != tag_tokens(description):
        raise ValueError('Whole-description HTML changed')
    if [m['body'] for m in macros(result)] != [m['body'] for m in macros(description)]:
        raise ValueError('Whole-description macros changed')
    return result, review, issues
