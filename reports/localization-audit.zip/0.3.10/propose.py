import copy,hashlib,json,re
from pathlib import Path
from catalogue import norm,key,stripen
from text_localization import macros,tag_tokens
from collections import Counter,defaultdict
D=Path(__file__).resolve().parent;W=D.parent;R=W/'anachronism-cn';S=W/'source-cache'
def j(p):return json.loads(p.read_text('utf-8-sig'))
catalog=j(D/'catalogue.json');plan=j(D/'name-plan.json')
# Rebuild from current catalogue after the user's explicit Elite override.
plan={x['id']:x for x in catalog if x['status']=='different' and x['number'] not in [538,707,1159]}
for x in catalog:
 if x['grade']=='Elite' and x['status']=='unmatched':plan[x['id']]={**x,'proposed':x['current'].replace('菁英型','精英型'),'reason':'用户本次确认Elite按Wiki精英型；只修订型号词，保留未有可靠资料的物品根名'}
assert len(plan)==106
(D/'name-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),'utf-8')
original=j(S/'repo-original-export.json');equipment=original['sf2e-anachronism.equipment.json']['entries']
primary={v['_id']:v for v in equipment.values()};enmap=defaultdict(list)
for en,v in equipment.items():enmap[key(en)].append(v)
physical={'equipment','weapon','armor','shield','consumable','ammo','backpack','treasure'}
groups=[
 ('Creator Capsule','造物胶囊','创造胶囊'),('Autopilot','自动驾驶仪','自动驾驶程序'),
 ('Chem Tank','化学储罐','化学罐'),('Full-Spectrum Sensor Suite','全频谱传感器组','全光谱传感器套件'),
 ('Keypad Lock','键盘密码锁','键盘锁'),('Adrenosuppressant Serum','肾上腺抑制血清','肾上腺素抑制血清'),
 ('Aerosol Spray Nozzle','气溶胶喷嘴','气雾喷嘴'),('Hellforged Plates','狱锻板甲','狱铸板甲'),
 ('Aqua Jets','水下喷射器','喷水推进器'),('Easypatcher','便捷修补器','便捷贴片'),
 ('Laser Grid','激光栅格','激光网'),('Lifesuit','生命服','维生服'),
 ('Myrmidon Siegebreaker','悍将破城甲','密耳弥多涅破城板甲'),('Neurocam','神经摄像机','神经记录仪'),
 ('Hardlight Handwraps','硬光缠手带','实光缠手带'),
 ('Mobility Enhancer (Augmentation)','行动力增强器','移动强化器'),
 ('Gnarefuroid Carapace','格纳雷弗甲壳','拾荒蜗族甲壳'),('Hardlight Series','硬光套装','实光套装'),
 ('Biometric Lock (Voice Recognition)','语音识别','声纹识别'),
 ('Motion Sensors (Tomographic)','断层扫描','断层成像'),
 ('Motion Sensors (Ultrasonic)','超声波传感器','超声传感器'),
 ('Motion Sensors (Ultrasonic)','运动传感器（超声波）','运动传感器（超声）'),
 ('Musical Instrument (Heavy)','重型乐器','大型乐器'),
 ('Musical Instrument (Heavy)','乐器（重型）','大型乐器'),
]
groupids={}
for base,old,new in groups:
 def belongs(en):
  e=norm(en);b=norm(base)
  if base=='Mobility Enhancer (Augmentation)':return e.startswith('mobility enhancer (augmentation,')
  if base=='Musical Instrument (Heavy)':return e.startswith('musical instrument (heavy,')
  return e==b or e.startswith(b+' (')
 groupids[base]={id for id,v in primary.items() if belongs(v['name'])}
 assert groupids[base],base

def get(o,path):
 for part in path.split('.'):
  if isinstance(o,list):o=o[int(part)] if part.isdigit() and int(part)<len(o) else None
  elif isinstance(o,dict):o=o.get(part)
  else:return None
 return o
def ownids(src):
 ids=set()
 if src.get('_id') in primary:ids.add(src['_id'])
 for value in [src.get('_stats',{}).get('compendiumSource'),src.get('flags',{}).get('core',{}).get('sourceId')]:
  if isinstance(value,str) and 'sf2e-anachronism.equipment.' in value:ids.add(value.split('.')[-1])
 if src.get('type') in physical:
  ids.update(x['_id'] for x in enmap[key(src.get('name',''))] if x.get('type')==src.get('type'))
 return ids
def hasenglish(text,phrase):
 text=norm(text);phrase=norm(phrase)
 aliases=[phrase]
 if phrase=='easypatcher':aliases.append('easy patcher')
 return any(re.search(r'(?<![a-z0-9])'+re.escape(p)+r'(?:s)?(?![a-z0-9])',text) for p in aliases)
def referenced(en,ids):
 return any(re.search(r'Compendium\.sf2e-anachronism\.equipment\.(?:Item\.)?'+re.escape(id)+r'(?:\]|\b)',en) for id in ids)
def eligible(en,src,base):
 ids=groupids[base]
 if ownids(src)&ids or referenced(en,ids):return True
 if '(' not in base:return hasenglish(en,base)
 root,qualifier=base.split(' (',1);qualifier=qualifier[:-1]
 return hasenglish(en,root) and hasenglish(en,qualifier)
def bilingual_like(cn,en,old):
 if norm(en) not in norm(old):return cn
 if old.endswith('（'+en+'）'):return cn+'（'+en+'）'
 if old.endswith(' ('+en+')'):return cn+' ('+en+')'
 return cn+' '+en

changes=[];allunits=[];updated={};held=[]
tagpat=re.compile(r'(</?[A-Za-z][^>]*>|<!--.*?-->)',re.S)
def edit(file,path,owner,field,old,en,src):
 assert isinstance(en,str),(file,path,'English source unavailable')
 new=old;reasons=[];eq=ownids(src)
 # Primary and exact same-item embedded names use the reviewed item identity.
 if field=='name' and src.get('type') in physical:
  matches=[primary[i] for i in eq if i in plan and primary[i].get('type')==src.get('type') and key(primary[i]['name'])==key(src.get('name',''))]
  targets={plan[m['_id']]['proposed'] for m in matches}
  if len(targets)==1:
   new=bilingual_like(next(iter(targets)),src['name'],old);reasons.append('same-English-item-name-and-type')
 if src.get('name')=='Haywire Autopilot' and en=='Haywire Autopilot':
  new=bilingual_like('失控自动驾驶',en,old);reasons.append('Wiki-explicit-bilingual-hazard-name')
 if new==old:
  # Process aligned HTML text nodes; attributes and all macro bodies are locked.
  parts=tagpat.split(old);eparts=tagpat.split(en)
  aligned=len(parts)==len(eparts) and all(parts[i]==eparts[i] for i in range(1,len(parts),2))
  for i in range(0,len(parts),2):
   text=parts[i];english=eparts[i] if aligned else en
   for base,a,b in sorted(groups,key=lambda x:-len(x[1])):
    if a in text:
     named=eligible(english,src,base)
     if base=='Aqua Jets' and not (hasenglish(english,base) or referenced(english,groupids[base])):named=False
     if named:text=text.replace(a,b);reasons.append('canonical-name:'+base)
     else:held.append({'file':file,'path':path,'oldTerm':a,'base':base,'English':english,'Chinese':text,'reason':'no same-node English/UUID/item identity evidence'})
   if '菁英型' in text:
    gearwords=r'\b(?:equipment|item|upgrade|augmentation|armor|armour|weapon|shield|serum|grenade|module|toolkit|tool|battery|capsule|version|grade|patch|kit|bioscanner|blaster|launcher|rifle)\w*\b'
    isgear=hasenglish(english,'elite') and (src.get('type') in physical or re.search(gearwords,english,re.I))
    iscreature=re.search(r'\belite\s+(?:creature|mercenary|soldier|trooper|war\s+machine|robot|demon|devil|gamer|player)',english,re.I)
    if isgear and not iscreature:text=text.replace('菁英型','精英型');reasons.append('user-confirmed-Elite-equipment-grade')
   parts[i]=text
  new=''.join(parts)
 if new==old:return
 assert tag_tokens(old)==tag_tokens(new),(file,path,'HTML attributes/order changed')
 assert [m['body'] for m in macros(old)]==[m['body'] for m in macros(new)],(file,path,'macro bodies changed')
 assert re.findall(r'\d+(?:\.\d+)?',old)==re.findall(r'\d+(?:\.\d+)?',new),(file,path,'numbers changed')
 changes.append({'file':file,'path':path,'sourceName':src.get('name'),'sourceType':src.get('type'),'sourceSlug':src.get('system',{}).get('slug'),
  'English':en,'old':old,'new':new,'reasons':sorted(set(reasons))})
 owner[field]=new

def collect_patch(file,patch,src,path):
 for field in ['name','description','content']:
  if field not in patch:continue
  p={'name':'name','description':'system.description.value','content':'text.content'}[field]
  en=get(src,p)
  if not isinstance(en,str):raise AssertionError((file,path,p))
  allunits.append((file,path+[field]));edit(file,path+[field],patch,field,patch[field],en,src)
 for field,patches in patch.items():
  if field in ['items','pages','subitems']:
   raw=src.get(field) if field!='subitems' else get(src,'system.subitems')
   assert isinstance(raw,list),(file,path,field)
   byid={s['_id']:s for s in raw}
   for i,p in enumerate(patches):
    item=byid[p['id']];assert item['name']==p['expectedName']
    collect_patch(file,p,item,path+[field,i])
  elif field=='extraFields':
   for i,p in enumerate(patches):
    en=get(src,p['path']);assert en==p['expected']
    edit(file,path+[field,i,'text'],p,'text',p['text'],en,src)
  elif field=='cnPrerequisites':
   for i,p in enumerate(patches):
    edit(file,path+[field,i,'text'],p,'text',p['text'],p['expected'],src)
  elif field.startswith('cnText_'):
   edit(file,path+[field,'text'],patches,'text',patches['text'],patches['expected'],src)
  elif field=='cnHolyModuleCorrection':
   edit(file,path+[field,'text'],patches,'text',patches['text'],patches['expectedDescription'],src)

for file,sourcepack in original.items():
 p=R/'translations'/file;tr=j(p);before=copy.deepcopy(tr)
 if not tr.get('mapping'):continue
 byid={s['_id']:s for s in sourcepack['entries'].values() if isinstance(s,dict)}
 for id,patch in tr['entries'].items():
  src=byid[id]
  if 'description' in patch and tr['mapping'].get('description')=='system.details.publicNotes':
   # Actor public notes have the same guarded text workflow, a different source path.
   edit(file,['entries',id,'description'],patch,'description',patch['description'],get(src,'system.details.publicNotes'),src)
   tmp={k:v for k,v in patch.items() if k!='description'};collect_patch(file,tmp,src,['entries',id]);patch.update(tmp)
  else:collect_patch(file,patch,src,['entries',id])
 if tr!=before:updated[file]=tr

(D/'proposed-translations').mkdir(exist_ok=True)
for file,data in updated.items():(D/'proposed-translations'/file).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n','utf-8')
(D/'proposals.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2),'utf-8')
(D/'held-references.json').write_text(json.dumps(held,ensure_ascii=False,indent=2),'utf-8')
print('PRIMARY PLAN',len(plan),'DISPLAY CHANGES',len(changes),'PACKS',Counter(c['file'] for c in changes),'HELD',len(held))
print('Changed names',sum(c['path'][-1]=='name' for c in changes),'changed text fields',sum(c['path'][-1]!='name' for c in changes))
for c in changes:
 if c['path'][-1]=='name' and c['file']=='sf2e-anachronism.equipment.json':print(c['sourceName'],c['old'],'=>',c['new'])
