import json,hashlib,zipfile,shutil,subprocess
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent/'anachronism-cn';O=D.parent.parent/'outputs'
def sha(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_text('utf-8-sig'))
def save(p,obj):
 b=(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
 if p.exists() and b'\r\n' in p.read_bytes():b=b.replace(b'\n',b'\r\n')
 p.write_bytes(b)
m=j(R/'module.json');m['version']='0.3.10';m['download']=m['download'].replace('/v0.3.9/','/v0.3.10/')
(R/'module.json').write_bytes((json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
report=j(R/'reports/equipment-name-audit-0.3.10.json');native=j(D/'0310-validation.json');index=j(D/'validation.json')
with zipfile.ZipFile(D/'baseline.zip') as z:baseline=z.read('reports/validation.json');v=json.loads(baseline)
v['previousMaintenanceUpdate']={'version':'0.3.9','record':v['maintenanceUpdate']}
v.update(native);v['historicalValidationSnapshot']='reports/localization-audit.zip:0.3.10/baseline-validation-0.3.9.json'
v['translationOutputHashes']={p.name:sha(p.read_bytes()) for p in sorted((R/'translations').glob('sf*.json'))}
v['searchIndexOutputHashes']={n:sha((R/'translations'/n).read_bytes()) for n in ['titles.json','labels.json']}
v['searchIndexCompatibility']=index
v['maintenanceUpdate']={'baseVersion':'0.3.9','scope':'All 1161 equipment names, matching display references, Wiki Elite override and actual corrected terminology',
 'equipmentNamesCorrected':106,'changedDisplayFields':188,'runtimeScriptsUnchanged':True,'mechanicalDataUnchangedFromBaseline':True,
 'termPairs':report['terminology']['masterPairs'],'newTermPairs':report['terminology']['newPairs'],'actualCorrectionTermPairs':report['terminology']['actualCorrectionPairs'],
 'consolidatedTermsSha256':report['terminology']['masterSha256'],'waveTermPairs':24,'report':'reports/equipment-name-audit-0.3.10.json','searchReport':'reports/search-index-validation-0.3.10.json'}
assert v['runtimeScriptSha256']==sha((R/'scripts/register.mjs').read_bytes())
assert v['displayScriptSha256']==sha((R/'scripts/display.mjs').read_bytes())
assert v['displayStringsSha256']==sha((R/'scripts/display-strings.mjs').read_bytes())
save(R/'reports/validation.json',v)
archive=R/'reports/localization-audit.zip';temp=D/'localization-audit-new.zip'
with zipfile.ZipFile(archive) as old,zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
 for info in old.infolist():
  if not info.filename.startswith('0.3.10/'):out.writestr(info,old.read(info.filename))
 out.writestr('0.3.10/baseline-validation-0.3.9.json',baseline)
 for n in ['live-wiki-equipment.json','wiki-expansion.json','fallback-authorities.json','unmatched-body-evidence.json','wiki-name-records.json','catalogue.json','name-plan.json','proposals.json','held-references.json','review-complete.json','0310-validation.json','validation.json','baseline-scalar-diff.json','catalogue.py','propose.py','finalize.py','package.py','test-indexes.mjs','validate_0310.mjs']:
  out.write(D/n,'0.3.10/'+n)
 out.writestr('0.3.10/aon-creator-capsule-check.json',json.dumps({'url':'https://2e.aonsrd.com/treasure/354','date':'2026-10-26','readVia':'fetch MCP after web open failed','EnglishIdentityVerified':True,'sevenGradesVerified':True,'ChineseAuthority':'SF2 Wiki Data:Items-Creator Capsule.json revision 21413','ChineseName':'创造胶囊','allSevenLocalNamesCorrected':True,'oldChineseTermRemainingInTranslationFiles':0},ensure_ascii=False,indent=2))
assert zipfile.ZipFile(temp).testzip() is None
shutil.copyfile(temp,archive)
hashes={p.relative_to(R).as_posix():sha(p.read_bytes()) for p in (R/'translations').glob('*.json')}
subprocess.run(['python','-X','utf8',str(R/'tools/build_search_indexes.py')],check=True,capture_output=True)
assert hashes=={p.relative_to(R).as_posix():sha(p.read_bytes()) for p in (R/'translations').glob('*.json')},'index builder not idempotent'
roots=['module.json','coverage.json','scripts','translations','README.md','THIRD-PARTY-NOTICES.md','licenses','reports'];files=[]
for root in roots:
 p=R/root;files.extend([p] if p.is_file() else sorted(x for x in p.rglob('*') if x.is_file()))
target=O/'anachronism-cn-0.3.10.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 assert set(z.namelist())=={p.relative_to(R).as_posix() for p in files}
 for p in files:assert z.read(p.relative_to(R).as_posix())==p.read_bytes(),str(p)
 assert json.loads(z.read('module.json'))['version']=='0.3.10'
shutil.copyfile(target,R/'dist/anachronism-cn.zip')
summary={'version':'0.3.10','packageFiles':len(files),'packageSha256':sha(target.read_bytes()),'packageBytes':target.stat().st_size,'archiveMatchesRepositoryBytes':True,'indexBuilderIdempotent':True,'runtimeAndSourceIdentityFilesUnchanged':True,'baselineMechanicalDataUnchanged':True,'equipmentNamesCorrected':106,'displayFieldsCorrected':188,'waveTermPairs':24,'masterTermPairs':795,'published':False}
save(D/'delivery-validation.json',summary);print(json.dumps(summary,ensure_ascii=False))
