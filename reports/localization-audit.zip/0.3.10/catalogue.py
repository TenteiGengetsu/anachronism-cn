import difflib,html,json,re,unicodedata,zipfile
from pathlib import Path
from collections import defaultdict,Counter
D=Path(__file__).resolve().parent;W=D.parent;R=W/'anachronism-cn';S=W/'source-cache'
def norm(s):
 s=html.unescape(unicodedata.normalize('NFKC',str(s)))
 s=''.join(c for c in s if unicodedata.category(c)!='Cf')
 return re.sub(r'\s+',' ',s.translate(str.maketrans({'’':"'",'‘':"'",'“':'"','”':'"','–':'-','—':'-','‑':'-'}))).casefold().strip()
def key(s):return re.sub('[^a-z0-9+]','',norm(s))
def zkey(s):return re.sub(r'[\W_]','',norm(s))
grades={'Commercial':'商用型','Tactical':'战术型','Advanced':'先进型','Superior':'卓越型','Elite':'精英型','Ultimate':'终极型','Paragon':'完美型'}
def splitgrade(s):
 m=re.fullmatch(r'(.+?) \(([^()]+)\)',s.strip())
 if m and m[2].title() in grades:return m[1],m[2].title()
 return s,None
def stripen(cn,en):
 if cn.endswith(' '+en):return cn[:-len(en)-1].rstrip()
 return cn
live=json.loads((D/'live-wiki-equipment.json').read_text('utf-8'))
pages={p['title']:p for p in live['pages'] if not p['missing']}
with zipfile.ZipFile(W.parent/'archives/terminology-review-2026-10-24.zip') as z:
 oldpages=json.loads(z.read('merged-wiki-pages.json'))
oldpages.update(pages)
for name in ['wiki-expansion.json','fallback-authorities.json']:
 if (D/name).exists():
  for p in json.loads((D/name).read_text('utf-8'))['pages']:
   oldpages[p['title']]=p
   if p['title'].startswith('Data:Items-') or p['title'] in pages:pages[p['title']]=p
(D/'all-wiki-pages.json').write_text(json.dumps(oldpages,ensure_ascii=False),'utf-8')
records=[]
def add(en,zh,page,rev,kind='item',family=None,description='',category='',extra=None):
 if not isinstance(en,str) or not isinstance(zh,str) or not re.search('[\u3400-\u9fff]',zh):return
 r={'en':en.strip(),'zh':zh.strip(),'page':page,'revid':rev,'kind':kind,'family':family or en,
    'description':description,'category':category}
 if extra:r.update(extra)
 if r not in records:records.append(r)
for title,p in pages.items():
 try:data=json.loads(p['content'])
 except (TypeError,ValueError):continue
 if title.endswith('.tabx'):
  schema=[f['name'] for f in data.get('schema',{}).get('fields',[])]
  for row in data.get('data',[]):
   v=dict(zip(schema,row))
   if title=='Data:译名表.tabx':add(v.get('Original'),v.get('Translation'),title,p['revid'],'live-glossary',description=v.get('Notes') or '',category=v.get('Category') or '')
   elif title in ['Data:武器.tabx','Data:护甲.tabx','Data:盾牌.tabx']:add(v.get('Name'),v.get('Name_CN'),title,p['revid'],{'Data:武器.tabx':'weapon','Data:护甲.tabx':'armor','Data:盾牌.tabx':'shield'}[title],description=v.get('Descriptions') or '',category=v.get('Category') or '')
  continue
 en=data.get('原文');zh=data.get('中文')
 if en and zh:
  add(en,zh,title,p['revid'],description=data.get('描述',''),category=data.get('物品分类',''),extra={'dataId':data.get('ID',data.get('id'))})
  for v in data.get('类型数据',[]):
   ven=v.get('类型名称');vzh=v.get('类型')
   add(ven,vzh,title,p['revid'],'variant',en,v.get('类型描述',''),data.get('物品分类',''),{'level':v.get('等级')})
   if isinstance(ven,str):
    # Some type fields only contain the subtype, not the full parent name.
    if en not in ven and not any(g.casefold() in ven.casefold() for g in grades):
     add(en+' ('+ven+')',zh+'（'+vzh+'）',title,p['revid'],'parent-subtype',en,v.get('类型描述',''),data.get('物品分类',''),{'level':v.get('等级')})
    for grade in grades:
     if ven.casefold().startswith(grade.casefold()+' '):
      alt=ven[len(grade)+1:]+' ('+grade+')'
      add(alt,vzh,title,p['revid'],'variant-prefix-alias',en,v.get('类型描述',''),data.get('物品分类',''),{'level':v.get('等级')})

# Explicit aliases are admitted after source/context review, not selected by fuzzy score.
manual={
 'Corossive Grenade':('腐蚀手雷','Data:Items-Corrosive Grenade.json','module-English-spelling-alias'),
 'Valediction Log':('临终日志','Data:Items-Validiction Log.json','wiki-English-spelling-alias'),
 'Machine Mind Serum':('机械心智血清','Data:Items-Machine Mind Serum (commerical).json','wiki-English-grade-spelling-alias'),
 'Myrmidon Siegebreaker':('密耳弥多涅破城板甲','Data:护甲.tabx','same-armor-description-and-stats'),
 'Hellforged Plates':('狱铸板甲','仿生人族裔','same-armor-main-page-heading'),
 'Gnarefuroid Carapace':('拾荒蜗族甲壳','拾荒蜗族族裔','canonical-ancestry-component'),
 'Aqua Jets':('喷水推进器','Data:护甲.tabx','explicit-bilingual-installed-upgrade'),
 'Full-Spectrum Sensor Suite':('全光谱传感器套件','Data:护甲.tabx','explicit-bilingual-installed-upgrade'),
 'Easypatcher':('便捷贴片','Data:护甲.tabx','explicit-bilingual-installed-upgrade'),
 'Chem Tank':('化学罐','Data:Feats-Flamespewer.json','explicit-bilingual-equipment-reference'),
 'Drift Drive Relay':('漂流引擎中继器','Data:护甲.tabx','explicit-bilingual-installed-upgrade'),
 'Energized Spikes':('充能尖刺','Data:护甲.tabx','explicit-bilingual-installed-upgrade'),
}
for en,(zh,page,kind) in manual.items():
 p=oldpages[page];assert not p['missing'];add(en,zh,page,p['revid'],kind)

for root in ['Biometric Lock','Motion Sensors','Musical Instrument']:
 p=pages['Data:Items-'+root+'.json'];data=json.loads(p['content'])
 for v in data['类型数据']:
  if root=='Musical Instrument':
   m=re.fullmatch(r'Musical Instrument \((Commercial|Tactical) (Handheld|Heavy)\)',v['类型名称'])
   assert m;add('Musical Instrument ('+m[2]+', '+m[1]+')',v['类型'],p['title'],p['revid'],'same-type-word-order-alias',root,v.get('类型描述',''))

idx=defaultdict(list)
for r in records:idx[key(r['en'])].append(r)
gloss=defaultdict(list)
for en,vs in json.loads((S/'terminology-index.json').read_text('utf-8-sig')).items():
 for r in vs:gloss[key(en)].append(r)
original=json.loads((S/'repo-original-export.json').read_text('utf-8-sig'))['sf2e-anachronism.equipment.json']['entries']
tr=json.loads((R/'translations/sf2e-anachronism.equipment.json').read_text('utf-8-sig'))['entries']
rows=[]
for i,(en,source) in enumerate(original.items(),1):
 id=source['_id'];current=stripen(tr[id]['name'],en);base,grade=splitgrade(en);matches=idx[key(en)]
 g=gloss[key(en)]; candidates=[];method='none'
 if g:
  # A single user glossary name is authoritative only for the same full term;
  # alternative/multiple meanings remain explicit review candidates.
  for v in g:candidates.append({'zh':v['zh'],'page':'用户译名表','kind':'user-glossary','notes':v.get('notes'),'row':v.get('row')})
  method='user-glossary'
 if not candidates and matches:
   candidates=matches;method='wiki-exact-normalized'
 if not candidates and grade:
  roots=[x for x in idx[key(base)] if x['kind'] not in ['variant','variant-prefix-alias']]
  if roots:
   candidates=[{**x,'zh':grades[grade]+x['zh'],'derivedGrade':grade} for x in roots];method='wiki-family-grade'
 if grade=='Elite':
  # User explicitly superseded workbook A402 during this audit: use Wiki精英型.
  candidates=[{**x,'zh':x['zh'].replace('菁英型','精英型'),'gradeAuthority':'本次用户明确指示：Elite装备型号按Wiki精英型；旧词表A402已过时'} for x in candidates]
 if en.startswith('Mobility Enhancer (Augmentation,'):
  candidates=[{**x,'zh':x['zh']+'（殖装）' if '殖装' not in x['zh'] else x['zh']} for x in candidates]
 # Crystal is an explicit module noun. This reviewed convention was fixed in0.3.9.
 cm=re.fullmatch(r'(?:(\+[123]) )?(Cycling|Gluon|Graviton|Photon|Quasar|Weapon Potency|Striking) Crystal(?: \(([^)]+)\))?',en)
 if cm:
  bonus,family,cgrade=cm.groups();root=next(x for x in idx[key(family)] if x['kind']=='item')
  candidates=[{**root,'zh':(bonus or '')+(grades[cgrade] if cgrade else '')+root['zh']+'水晶'}];method='reviewed-crystal-convention'
 names=sorted(set(v['zh'] for v in candidates))
 proposed=names[0] if len(names)==1 else None
 if proposed and zkey(proposed)==zkey(current):status='consistent'
 elif proposed:status='different'
 elif candidates:status='conflicting-source-names'
 else:status='unmatched'
 near=[]
 if not candidates:
  query=key(base);keys=[k for k in idx if .65*len(query)<=len(k)<=1.5*len(query)]
  for hit in difflib.get_close_matches(query,keys,n=3,cutoff=.74):
   vals=[v for v in idx[hit] if v['kind'] not in ['variant','variant-prefix-alias']]
   near.extend(vals[:2])
 row={'number':i,'id':id,'en':en,'base':base,'grade':grade,'current':current,'proposed':proposed,'status':status,'method':method,
  'kind':source.get('type'),'level':source.get('system',{}).get('level'),
  'publication':source.get('system',{}).get('publication'),'candidates':candidates,'fuzzy':near,
  'sourceDescription':source.get('system',{}).get('description',{}).get('value','')}
 rows.append(row)
(D/'wiki-name-records.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),'utf-8')
(D/'catalogue.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),'utf-8')
print('records',len(records),'entries',len(rows),'families',len(set(r['base'] for r in rows)),Counter(r['status'] for r in rows))
for r in rows:
 if r['status'] in ['different','conflicting-source-names']:print(r['number'],r['en'],r['current'],'=>',r['proposed'] or sorted(set(x['zh'] for x in r['candidates'])),r['method'])
