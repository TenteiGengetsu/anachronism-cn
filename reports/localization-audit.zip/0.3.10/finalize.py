import hashlib,json,re,zipfile
from pathlib import Path
from collections import Counter
from text_localization import macros,tag_tokens
D=Path(__file__).resolve().parent; W=D.parent; R=W/'anachronism-cn'; O=W.parent/'outputs'
def j(p):return json.loads(p.read_text('utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,v):
 b=(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
 if p.exists() and b'\r\n' in p.read_bytes():b=b.replace(b'\n',b'\r\n')
 p.write_bytes(b)
def key(s):return re.sub('[^a-z0-9+]','',s.casefold())
plan=j(D/'name-plan.json');changes=j(D/'proposals.json');catalog=j(D/'catalogue.json')
before=j(D/'baseline-expected-export.json');after=j(D/'repo-expected-export.json')
diffs=[]
def compare(a,b,path):
 assert type(a)==type(b),(path,'type')
 if isinstance(a,dict):
  assert a.keys()==b.keys(),(path,'keys')
  for k in a:compare(a[k],b[k],path+[k])
 elif isinstance(a,list):
  assert len(a)==len(b),(path,'array')
  for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+[i])
 elif a!=b:
  assert isinstance(a,str),(path,'non-text rule change')
  assert path[-1]=='name' or path[-3:]==['system','description','value'],(path,'outside name/description')
  assert tag_tokens(a)==tag_tokens(b),(path,'HTML')
  assert [m['body'] for m in macros(a)]==[m['body'] for m in macros(b)],(path,'macro/UUID')
  assert re.findall(r'\d+(?:\.\d+)?',a)==re.findall(r'\d+(?:\.\d+)?',b),(path,'number')
  diffs.append({'path':path,'old':a,'new':b})
compare(before,after,[])
assert len(diffs)==len(changes),(len(diffs),len(changes))
assert Counter((c['old'],c['new']) for c in changes)==Counter((c['old'],c['new']) for c in diffs)
with zipfile.ZipFile(D/'baseline.zip') as z:
 for n in z.namelist():
  if n.startswith('scripts/') or n=='tools/source-names.json' or n=='README.md':assert z.read(n)==(R/n).read_bytes(),n
 baselinevalidation=json.loads(z.read('reports/validation.json'))
baselinecrystals=j(R/'reports/crystal-terminology-0.3.9.json')
tr=j(R/'translations/sf2e-anachronism.equipment.json')['entries']
source=j(W/'source-cache/repo-original-export.json')['sf2e-anachronism.equipment.json']['entries']
for en,item in source.items():
 if re.search(r'\bCrystal(?: \([^)]*\))?$',en):
  assert before['sf2e-anachronism.equipment.json']['entries'][en]==after['sf2e-anachronism.equipment.json']['entries'][en],en
queries={};titles=j(R/'translations/titles.json')['sf2e-anachronism.equipment']['titles']
for id,c in plan.items():
 display=c['proposed']+' '+c['en']; assert tr[id]['name']==display,(id,display)
 assert titles[id]==display and titles[c['en']]==display
 hits=[i['_id'] for en,i in source.items() if c['proposed'] in titles[i['_id']]]
 assert id in hits;queries[c['proposed']]=hits
 assert source[c['en']]['system']['slug']
assert sum('(Elite)' in x for x in source)==52
assert all('精英型' in tr[x['_id']]['name'] for en,x in source.items() if en.endswith('(Elite)'))
assert not any('菁英型' in v['name'] for v in tr.values())
units=j(D/'review-units-final.json')
review={'scope':'Equipment terminology and changed display references only; unchanged rules prose was not retranslated or comprehensively reproofread.',
 'passes':['English comparison: identity, scope and mistranslation','Second English comparison: terminology and same-context use','Independent Chinese reading of final changed names and text nodes'],
 'units':[{**u,'finalSha256':sha(u['new'].encode('utf-8')),'faithfulness':True,'terminologyAndContext':True,'ChineseReading':True} for u in units],
 'deduplicatedChangedUnits':len(units),'displayFields':len(changes),'reviewCorrections':['Removed automatic replacement of generic hardlight and underwater-jet wording.','Haywire Autopilot uses the explicit Wiki hazard title 失控自动驾驶, including token name.']}
save(D/'review-complete.json',review)
pairs=[('创造胶囊','Creator Capsule'),('自动驾驶程序','Autopilot'),('化学罐','Chem Tank'),('全光谱传感器套件','Full-Spectrum Sensor Suite'),('键盘锁','Keypad Lock'),('肾上腺素抑制血清','Adrenosuppressant Serum'),('气雾喷嘴','Aerosol Spray Nozzle'),('狱铸板甲','Hellforged Plates'),('喷水推进器','Aqua Jets'),('便捷贴片','Easypatcher'),('激光网','Laser Grid'),('维生服','Lifesuit'),('密耳弥多涅破城板甲','Myrmidon Siegebreaker'),('神经记录仪','Neurocam'),('实光缠手带','Hardlight Handwraps'),('移动强化器（殖装）','Mobility Enhancer (Augmentation)'),('拾荒蜗族甲壳','Gnarefuroid Carapace'),('实光套装','Hardlight Series'),('生物识别锁（声纹识别）','Biometric Lock (Voice Recognition)'),('运动传感器（断层成像）','Motion Sensors (Tomographic)'),('运动传感器（超声）','Motion Sensors (Ultrasonic)'),('大型乐器','Musical Instrument (Heavy)'),('精英型','Elite'),('失控自动驾驶','Haywire Autopilot')]
with zipfile.ZipFile(D/'baseline.zip') as z:lines=z.read('reports/terms.tsv').decode('utf-8-sig').splitlines()
master={key(en):(cn,en) for cn,en in (l.split('\t') for l in lines)};assert len(master)==len(lines)
with zipfile.ZipFile(W.parent/'archives/terminology-review-2026-10-24.zip') as z:oldterms=json.loads(z.read('final-audit.json'))
classifications={key(d['English']):d['decision'] for d in oldterms['decisions'] if d['decision'].startswith('retain-')}
for l in (O/'恒星武士水晶修订译名.tsv').read_text('utf-8-sig').splitlines():
 cn,en=l.split('\t');classifications[key(en)]='retain-correction'
assert set(master)<=set(classifications)
assert Counter(classifications[k] for k in master)==Counter({'retain-new':701,'retain-correction':72})
for cn,en in pairs:master[key(en)]=(cn,en);classifications[key(en)]='retain-correction'
content=''.join(cn+'\t'+en+'\n' for cn,en in sorted(master.values(),key=lambda x:x[1].casefold()))
(R/'reports/terms.tsv').write_bytes(content.encode('utf-8'));(O/'新增及修订译名汇总.tsv').write_bytes(content.encode('utf-8'))
wave=''.join(cn+'\t'+en+'\n' for cn,en in sorted(pairs,key=lambda x:x[1].casefold()))
(O/'装备修订译名.tsv').write_bytes(wave.encode('utf-8'));(R/'reports/equipment-term-corrections.tsv').write_bytes(wave.encode('utf-8'))
assert len(master)==795
exceptions={538:'Wiki型号字段重复法术安瓿，保留模组英文对应的完整名称。',707:'Wiki型号字段重复法术安瓿，保留模组英文对应的完整名称。',1159:'Wiki型号字段漏写Glow Up的法术名，保留战术型焕发光彩法术安瓿。'}
decisions=[]
for c in catalog:
 row={k:c[k] for k in ['number','id','en','current','status','method']};row['final']=tr[c['id']]['name'];row['changed']=c['id'] in plan
 row['authority']=[{k:v[k] for k in ['en','zh','page','revid','kind','row','notes','gradeAuthority'] if k in v} for v in c['candidates']]
 if c['number'] in exceptions:row['note']=exceptions[c['number']]
 elif c['status']=='unmatched':row['note']='未确认完整名称的可靠对应，保留现有补译；Elite仅按用户指示修订型号词。' if row['changed'] else '未确认完整名称的可靠对应，保留现有补译；未按近似英文强行匹配。'
 decisions.append(row)
counts=Counter(classifications[k] for k in master)
report={'version':'0.3.10','baselineVersion':'0.3.9','equipmentAudited':len(catalog),'baselineMatchCounts':dict(Counter(c['status'] for c in catalog)),
 'equipmentNamesCorrected':len(plan),'equipmentEliteGradesCorrected':52,'displayFieldsChanged':len(changes),'namesChanged':sum(c['path'][-1]=='name' for c in changes),'textFieldsChanged':sum(c['path'][-1]!='name' for c in changes),
 'sources':{'site':'https://sf2.huijiwiki.com','sourceModule':'sf2e-anachronism 2.4.0 preserved export','glossary':'User workbook, 1493 original data rows preserved in source cache','currentWikiInventory':9191,'wikiNamespaceScope':[0,3500],'currentEquipmentAndTablePages':328,'additionalOrRefreshedWikiPages':326},
 'userOverride':{'English':'Elite','Chinese':'精英型','scope':'Equipment grade names and matching display references','supersedes':'Workbook A402 菁英（型）','originalWorkbookModified':False},
 'reviewScope':review['scope'],'reviewPasses':review['passes'],'reviewedChangedUnits':len(units),'mechanicalDataUnchangedFrom039':True,'idsSlugsAutomationLinksAndMacroBodiesUnchangedFrom039':True,'runtimeScriptsUnchanged':True,'crystalTranslationsFrom039Unchanged':True,
 'terminology':{'wavePairs':len(pairs),'masterPairs':len(master),'newPairs':counts['retain-new'],'actualCorrectionPairs':counts['retain-correction'],'format':'Chinese TAB English; no headings, notes, duplicate English keys, or extra columns','masterSha256':sha(content.encode('utf-8'))},
 'notes':['Mobility Enhancer augmentation and armor upgrade kept separate.','Generic hardlight wording remains unchanged; named Hardlight Series and Handwraps follow Wiki.','Gnarefuroid Carapace uses the verified Wiki ancestry component; the complete item name is composed, not a quoted Wiki heading.','Corossive/Corrosive Grenade, Valediction/Validiction Log and commerical spelling aliases are recorded without changing module English or IDs.','Starday Night Special is not forced to match the different Wiki title Saturday Night Special.','Three malformed Wiki type labels are retained as source-field anomalies, not classified as Wiki mistranslations.','No new rule-value correction; existing authorized Holy Module Commercial 2d4 correction retained.'],
 'decisions':decisions,'changes':changes,'heldAmbiguousReferences':j(D/'held-references.json')}
save(R/'reports/equipment-name-audit-0.3.10.json',report)
save(D/'baseline-scalar-diff.json',diffs)
save(R/'reports/search-index-validation-0.3.10.json',{'version':'0.3.10','primaryEquipmentNamesChecked':len(catalog),'correctedChineseQueries':queries,'correctedNamesChecked':len(plan),'all52EliteGradesCorrect':True,'allStableIdsAndEnglishAliasesPreserved':True,'allMainNamesBilingual':True,'builderIdempotent':True,'liveFoundryTested':False})
print(json.dumps({k:report[k] for k in ['equipmentAudited','equipmentNamesCorrected','displayFieldsChanged','namesChanged','textFieldsChanged','terminology']},ensure_ascii=False))
