import assert from 'node:assert/strict';
globalThis.Hooks={on(){}};
const m=await import('../anachronism-cn/scripts/display.mjs');
const {DISPLAY_STRINGS:D,DISPLAY_NAME_KEYS:N,SOURCE_ACTOR_ITEMS:A}=await import('../anachronism-cn/scripts/display-strings.mjs');
assert.equal(D['Effect: Rebellious Defiance'],'效果：叛逆反抗 Effect: Rebellious Defiance');
assert(Object.isFrozen(D));assert(Object.isFrozen(N));assert(Object.isFrozen(A));
for(const ids of Object.values(A))assert(Object.isFrozen(ids));
for(const key of N){assert(Object.hasOwn(D,key));assert(D[key].includes(key),`lost source name ${key}`);assert(/[\u3400-\u9fff]/u.test(D[key]),`missing Chinese ${key}`)}
assert.equal(Object.getOwnPropertyDescriptor(Object.prototype,'displayTest'),undefined);
for(const key of ['__proto__','constructor','toString'])assert.equal(m.translateRenderedText(key),key);
const own=Object.fromEntries([['__proto__','原型安全']]);assert.equal(m.translateRenderedText('__proto__',own),'原型安全');
assert.equal(m.isSourceDocument({uuid:'Compendium.sf2e-anachronism-fake.spells.Item.a'}),false);
assert.equal(m.isSourceDocument({flags:{core:{sourceId:'Compendium.sf2e-anachronism.spells.Item.a'}}}),true);
assert.equal(m.isSourceItem({id:'later-added',uuid:'Compendium.pf2e.spells-srd.Item.a'},{sourceId:Object.keys(A)[0]}),false);
console.log(JSON.stringify({passed:true,nameKeys:N.length,strings:Object.keys(D).length,actors:Object.keys(A).length,embeddedIds:Object.values(A).reduce((n,a)=>n+a.length,0)}));
