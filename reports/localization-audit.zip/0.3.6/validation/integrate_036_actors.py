import json,hashlib,re,sys
from pathlib import Path
W=Path(__file__).resolve().parent;R=W/'anachronism-cn';A=W/'034-actors-a'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
def put(p,d):
 old=p.read_bytes() if p.exists() else b'';b=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
 p.write_bytes(b.replace(b'\n',b'\r\n') if b'\r\n' in old else b)
assert not load(A/'remaining.json'),'Actor review not complete'
assert not load(A/'compositions-awaiting-read.json'),'Composed text not read'
candidate=load(A/'candidate-current.json');original=load(W/'repo-original-export.json');records=[]
for file,c in candidate.items():
 if file=='sf2e-anachronism.guilt-of-the-grave-world-bestiary.json':continue
 p=R/'translations'/file;before=load(p);out=load(p)
 assert set(c['entries'])=={v['_id'] for v in original[file]['entries'].values()},file
 out['entries']=c['entries']
 for e in out['entries'].values():
  if 'publicNotes' in e:out['mapping']['publicNotes']='system.details.publicNotes'
  for k in e:
   if not k.startswith('cnText_'):continue
   path=k[len('cnText_'):].replace('_','.')
   assert path.startswith(('system.','prototypeToken.'))
   spec={'path':path,'converter':'sf2eAnachronismCnText'}
   assert k not in out['mapping'] or out['mapping'][k]==spec
   out['mapping'][k]=spec
 put(p,out);records.append({'file':file,'actors':len(c['entries']),'changedEntriesBeforeBilingualRebuild':sum(before['entries'].get(k)!=v for k,v in c['entries'].items()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
m=load(R/'module.json');m['esmodules']=['scripts/register.mjs','scripts/display.mjs'];put(R/'module.json',m)
put(W/'036-integration.json',records)
print(json.dumps(records,ensure_ascii=False))
