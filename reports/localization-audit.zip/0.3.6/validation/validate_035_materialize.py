import copy,json,re,zipfile
from pathlib import Path
from text_localization import macros,tag_tokens
W=Path(__file__).parent; R=W/'anachronism-cn'
Z=zipfile.ZipFile('C:/Users/v_pengxchen/Downloads/babele-directory-export.zip')
def get(o,p):
    for k in p.split('.'):
        if isinstance(o,list):o=o[int(k)] if k.isdigit() and int(k)<len(o) else None
        else:o=o.get(k) if isinstance(o,dict) else None
    return o
def put(o,p,v):
    parts=p.split('.')
    for k in parts[:-1]:o=o[int(k)] if isinstance(o,list) else o[k]
    if isinstance(o,list):o[int(parts[-1])]=v
    else:o[parts[-1]]=v
def textcheck(a,b,context):
    assert isinstance(a,str) and isinstance(b,str),context
    assert tag_tokens(a)==tag_tokens(b),(context,'tags')
    assert [m['body'] for m in macros(a)]==[m['body'] for m in macros(b)],(context,'macros')
def guards(obj,patch):return all(get(obj,g['path'])==g['expected'] for g in patch.get('guards',[]))
def display(p,item=False):
    assert all(k not in ['__proto__','constructor','prototype'] for k in p.split('.'))
    if item:return bool(re.fullmatch(r'system\.(?:requirements|area\.details|selfEffect\.name|overlays\.[A-Za-z0-9_-]+\.name|subitems\.\d+\.(?:name|system\.description\.value)|spell\.(?:name|system\.description\.value)|rules\.\d+\.(?:label|suboptions\.\d+\.label))',p))
    return p=='prototypeToken.name' or bool(re.fullmatch(r'system\.(?:details\.(?:description|disable|routine|reset|crew|pilotingCheck|speed|passengers|blurb|languages\.details|gender\.value)|attributes\.(?:stealth\.details|hp\.details|ac\.details|speed\.details|allSaves\.value)|perception\.details|skills\.[a-z]+\.(?:note|special\.\d+\.label))',p))
def identity(obj,patch,path):
    value=get(obj,path)
    return isinstance(value,str) and bool(value) and any(g['path']==path and g['expected']==value for g in patch.get('guards',[]))
def safe_extra(obj,patch):
    path=patch['path']
    assert display(path,True) and guards(obj,patch),path
    child=re.match(r'system\.subitems\.(\d+)\.',path)
    if child:assert identity(obj,patch,f'system.subitems.{child[1]}._id'),path
    if path.startswith('system.spell.'):assert identity(obj,patch,'system.spell._id'),path
    rule=re.fullmatch(r'system\.rules\.(\d+)\.(label|suboptions\.(\d+)\.label)',path)
    if rule:
        root=f'system.rules.{rule[1]}'
        assert identity(obj,patch,root+'.key'),path
        key=get(obj,root+'.key')
        if key=='RollOption':
            assert identity(obj,patch,root+'.option'),path
            if rule[3] is not None:assert identity(obj,patch,root+f'.suboptions.{rule[3]}.value'),path
        elif key=='Strike' and rule[2]=='label':assert identity(obj,patch,root+'.slug'),path
        else:raise AssertionError(path)
count=changed=0;original={};expected={};counts={}
for file in sorted((R/'translations').glob('sf2e-anachronism.*.json')):
    src=json.loads(Z.read(file.name));tr=json.loads(file.read_text(encoding='utf8'));original[file.name]=src;out=copy.deepcopy(src)
    if not tr.get('mapping'):expected[file.name]=out;continue
    for key,source in src['entries'].items():
        count+=1; target=out['entries'][key];patch=tr['entries'].get(source['_id'],{})
        for f,spec in tr['mapping'].items():
            if f not in patch:continue
            path=spec if isinstance(spec,str) else spec['path'];value=get(source,path)
            if value is None:continue
            v=patch[f]
            if isinstance(spec,str):
                assert path in ['name','system.description.value','system.details.publicNotes']
                textcheck(value,v,(file.name,key,path));put(target,path,v)
            elif f=='cnHolyModuleCorrection':
                assert source['_id']=='he1AD9ck10fLSvWn' and value['description']['value']==v['expectedDescription']
                assert value['rules'][1]['value']==3
                vv=copy.deepcopy(value);vv['rules'][1]['value']=2;vv['description']['value']=v['text'];put(target,path,vv)
                textcheck(value['description']['value'],v['text'],(file.name,key,path))
            elif f=='cnPrerequisites':
                vv=copy.deepcopy(value)
                for p in v:
                    assert vv[p['index']]['value']==p['expected'];textcheck(p['expected'],p['text'],(file.name,key,f));vv[p['index']]['value']=p['text']
                put(target,path,vv)
            elif f in ['items','pages']:
                vv=copy.deepcopy(value)
                for p in v:
                    obj=next((x for x in vv if x['_id']==p['id']),None)
                    assert obj is not None and obj['name']==p['expectedName'],(file.name,key,p['id'],'source identity')
                    for pf,dest,guard in [('name','name','expectedName'),('description','system.description.value','expectedDescription'),('content','text.content','expectedContent')]:
                        if pf not in p:continue
                        assert get(obj,dest)==p[guard],(file.name,key,p['id'],dest,'stale')
                        textcheck(p[guard],p[pf],(file.name,key,p['id'],dest));put(obj,dest,p[pf])
                    for extra in p.get('extraFields',[]):
                        ep=extra['path'];safe_extra(obj,extra)
                        assert get(obj,ep)==extra['expected'];textcheck(extra['expected'],extra['text'],(file.name,key,p['id'],ep));put(obj,ep,extra['text'])
                put(target,path,vv)
            elif f.startswith('cnText_'):
                assert display(path) and guards(source,v) and value==v['expected'],(file.name,key,path)
                textcheck(value,v['text'],(file.name,key,path));put(target,path,v['text'])
            else:raise AssertionError(f)
        if target!=source:changed+=1
    expected[file.name]=out;counts[file.name]=len(src['entries'])
assert count==5616,count
for name,data in [('repo-original-export.json',original),('repo-expected-export.json',expected)]:
    (W/name).write_text(json.dumps(data,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps({'objects':count,'changed':changed,'allSourceGuards':True,'allOrderedTagsAndMacros':True}))
