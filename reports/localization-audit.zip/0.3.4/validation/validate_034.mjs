import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';
const W=path.dirname(fileURLToPath(import.meta.url));
const R=path.join(W,'anachronism-cn');
const native=path.join(W,'babele-native-2.9.1/module/script');
const {FieldMapping}=await import(pathToFileURL(path.join(native,'mapping/field-mapping.js')));
const {ConverterRegistry}=await import(pathToFileURL(path.join(native,'converter/converter-registry.js')));
const {TranslationEntries}=await import(pathToFileURL(path.join(native,'translation/translation-entries.js')));
let coreReads=0;const callbacks=new Map();const messages=[];
globalThis.Hooks={once(name,cb){callbacks.set(name,cb);}};
globalThis.game={system:{id:'pf2e'},modules:new Map([['sf2e-anachronism',{active:true,version:'2.4.0'}]]),i18n:{},user:{isGM:true},settings:{get(ns){if(ns==='core'){coreReads++;throw new Error('core.language is not registered');}return false;}}};
globalThis.foundry={utils:{Collection:Map,parseUuid(uuid){return typeof uuid==='string'?{id:uuid.split('.').at(-1)}:null;}}};
globalThis.ui={notifications:{warn(message){messages.push(message);}}};
const runtime=await import(pathToFileURL(path.join(R,'scripts/register.mjs')));
let registered=[];let registry=new ConverterRegistry();
const facade={register(r){registered.push(r);},registerConverter(name,c){registry.register(name,c);}};
callbacks.get('babele.init')(facade);
assert.equal(coreReads,0);
assert(registered.some(x=>x.lang==='cn.foundry_chn'));
game.i18n.lang='zh-Hans.custom';callbacks.get('setup')();callbacks.get('ready')();
assert(registered.some(x=>x.lang==='zh-Hans.custom'));
assert.equal(messages.length,0);
for(const lang of ['cn','cn.foundry_chn','zh','zh-CN','zh-cn','zh-Hans','zh-hans','zh-Hans.custom'])assert(runtime.isChineseLanguage(lang));
assert(!runtime.isChineseLanguage('en'));
const original=JSON.parse(await fs.readFile(path.join(W,'repo-original-export.json'),'utf8'));
const expected=JSON.parse(await fs.readFile(path.join(W,'repo-expected-export.json'),'utf8'));
function set(data,p,v){const parts=p.split('.');for(const k of parts.slice(0,-1))data=data[k];data[parts.at(-1)]=v;}
let checked=0,matched=0,fields=0,embedded=0,mechanicalExceptions=0;
for(const [file,pack]of Object.entries(original)){
 const translation=JSON.parse(await fs.readFile(path.join(R,'translations',file),'utf8'));
 if(!translation.mapping)continue;
 const matcher=new TranslationEntries(translation.entries);
 const mappings=Object.entries(translation.mapping).map(([name,m])=>new FieldMapping(name,m,registry));
 for(const [key,source]of Object.entries(pack.entries)){
  const pristine=structuredClone(source),actual=structuredClone(source);const match=matcher.matchFor(source);checked++;
  if(match.matched){
   matched++;
   for(const mapping of mappings){
    const value=mapping.translate(source,match.entry,{currentCompendium:{metadata:{id:file.replace(/\.json$/,'')}}});
    if(value!==undefined&&value!==null){set(actual,mapping.path,value);fields++;if(mapping.field==='items'||mapping.field==='pages')embedded++;}
   }
  }
  assert.deepEqual(source,pristine,`${file}/${key}: input mutation`);
  assert.deepEqual(actual,expected[file].entries[key],`${file}/${key}: native materialization mismatch`);
  assert.equal(actual._id,source._id);
  const rules=structuredClone(source.system?.rules);
  if(file==='sf2e-anachronism.equipment.json'&&source._id==='he1AD9ck10fLSvWn'){
   assert.equal(rules[1].value,3);rules[1].value=2;mechanicalExceptions++;
  }
  assert.deepEqual(actual.system?.rules,rules);
 }
 assert.equal(matcher.matchFor({_id:'missing-id',name:'missing-name'}).matched,false);
}
assert.equal(checked,5616);assert.equal(mechanicalExceptions,1);
const p=[{value:'Original',extra:4}];
assert.equal(runtime.translatePrerequisites({value:p,translation:[{index:0,expected:'stale',text:'译文'}]}),undefined);
assert.equal(runtime.translatePrerequisites({value:p,translation:[{index:0,expected:'Original',text:'译文'},{index:0,expected:'Original',text:'另一译文'}]}),undefined);
assert.deepEqual(p,[{value:'Original',extra:4}]);
const items=[{_id:'b',name:'Second',system:{description:{value:'Second body'},rules:[{key:'Test',value:2}]}},{_id:'a',name:'First',system:{description:{value:'Edited body'},rules:[{key:'Test',value:1}]}}];
const patched=runtime.translateItems({value:items,translation:[{id:'a',expectedName:'First',name:'第一',expectedDescription:'Old body',description:'描述'},{id:'b',expectedName:'Second',name:'第二',expectedDescription:'Second body',description:'正文'}]});
assert.equal(patched[0].name,'第二');assert.equal(patched[0].system.description.value,'正文');
assert.equal(patched[1].name,'第一');assert.equal(patched[1].system.description.value,'Edited body');
assert.equal(items[0].name,'Second');assert.equal(items[1].name,'First');


// New page and visible-field converters must retain upstream edits and input objects.
const pageSource=[{_id:'page1',name:'Mystic',text:{content:'<p>Source</p>',format:1},flags:{test:2}}];
const pagePatch=[{id:'page1',expectedName:'Mystic',name:'秘术师',expectedContent:'<p>Source</p>',content:'<p>译文</p>'}];
const pageTarget=runtime.translatePages({value:pageSource,translation:pagePatch});
assert.equal(pageTarget[0].text.content,'<p>译文</p>');
assert.equal(pageSource[0].text.content,'<p>Source</p>');
assert.equal(pageTarget[0].text.format,1);assert.deepEqual(pageTarget[0].flags,{test:2});
const stalePage=structuredClone(pageSource);stalePage[0].text.content='<p>Updated upstream</p>';
assert.equal(runtime.translatePages({value:stalePage,translation:pagePatch})[0].text.content,'<p>Updated upstream</p>');
const nativePageMap=new FieldMapping('pages',{path:'pages',converter:'sf2eAnachronismCnPages'},registry);
assert.deepEqual(nativePageMap.translate({pages:pageSource},{pages:pagePatch}),pageTarget);
const noteSource={system:{attributes:{hp:{details:'Rejuvenation',value:10}}}};
const noteMap=new FieldMapping('cnText_system_attributes_hp_details',{path:'system.attributes.hp.details',converter:'sf2eAnachronismCnText'},registry);
assert.equal(noteMap.translate(noteSource,{cnText_system_attributes_hp_details:{expected:'Rejuvenation',text:'复生'}}),'复生');
assert.equal(noteSource.system.attributes.hp.details,'Rejuvenation');
for(const path of ['system.rules.0.value','system.slug','system.attributes.hp.value','__proto__.polluted','system.constructor.name']){
 assert.equal(runtime.translateDisplayText({value:'source',translation:{expected:'source',text:'译文'},source:noteSource,field:'cnText_test',path}),undefined);
}
assert.equal(runtime.translateDisplayText({value:'changed',translation:{expected:'source',text:'译文'},source:noteSource,field:'cnText_test',path:'system.attributes.hp.details'}),undefined);
assert.equal(runtime.translateDisplayText({value:'source',translation:{expected:'source',text:'译文',guards:[{path:'_id',expected:'missing'}]},source:noteSource,field:'cnText_test',path:'system.attributes.hp.details'}),undefined);
const inner=[{_id:'item1',name:'Thing',system:{subitems:[{_id:'child1',name:'Child',system:{description:{value:'Body'}}}],rules:[{key:'Other',value:4}],requirements:'a hand'}}];
const innerPatch=[{id:'item1',expectedName:'Thing',extraFields:[{path:'system.subitems.0.name',expected:'Child',text:'子物品',guards:[{path:'system.subitems.0._id',expected:'child1'}]},{path:'system.rules.0.value',expected:'4',text:'9'}]}];
assert.equal(runtime.translateItems({value:inner,translation:innerPatch})[0].system.subitems[0].name,'子物品');
assert.deepEqual(runtime.translateItems({value:inner,translation:innerPatch})[0].system.rules,inner[0].system.rules);
const different=structuredClone(inner);different[0].system.subitems[0]._id='child2';
assert.equal(runtime.translateItems({value:different,translation:innerPatch})[0].system.subitems[0].name,'Child');
assert.equal(inner[0].system.subitems[0].name,'Child');
const missingGuard=structuredClone(innerPatch);delete missingGuard[0].extraFields[0].guards;
assert.equal(runtime.translateItems({value:inner,translation:missingGuard})[0].system.subitems[0].name,'Child');
const nullField=[{id:'item1',expectedName:'Thing',extraFields:[null,{}, {path:'system.requirements',expected:'a hand',text:'一只手'}]}];
assert.equal(runtime.translateItems({value:inner,translation:nullField})[0].system.requirements,'一只手');
const ruleItems=[{_id:'ruleItem',name:'Power',system:{rules:[{key:'Strike',slug:'fixed-slug',label:'Claw'},{key:'Strike',label:'Limb Strike'},{key:'RollOption',option:'form',label:'Form',suboptions:[{value:'swarm',label:'Swarm Form'}]}]}}];
const rulePatches=[{id:'ruleItem',expectedName:'Power',extraFields:[
 {path:'system.rules.0.label',expected:'Claw',text:'爪',guards:[{path:'system.rules.0.key',expected:'Strike'},{path:'system.rules.0.slug',expected:'fixed-slug'}]},
 {path:'system.rules.1.label',expected:'Limb Strike',text:'肢体打击',guards:[{path:'system.rules.1.key',expected:'Strike'}]},
 {path:'system.rules.2.label',expected:'Form',text:'形态',guards:[{path:'system.rules.2.key',expected:'RollOption'},{path:'system.rules.2.option',expected:'form'}]},
 {path:'system.rules.2.suboptions.0.label',expected:'Swarm Form',text:'集群形态',guards:[{path:'system.rules.2.key',expected:'RollOption'},{path:'system.rules.2.option',expected:'form'},{path:'system.rules.2.suboptions.0.value',expected:'swarm'}]},
]}];
const ruleResult=runtime.translateItems({value:ruleItems,translation:rulePatches});
assert.equal(ruleResult[0].system.rules[0].label,'爪');assert.equal(ruleResult[0].system.rules[0].slug,'fixed-slug');
assert.equal(ruleResult[0].system.rules[1].label,'Limb Strike');
assert.equal(ruleResult[0].system.rules[2].label,'形态');assert.equal(ruleResult[0].system.rules[2].suboptions[0].label,'集群形态');
assert.equal(ruleItems[0].system.rules[0].label,'Claw');
const changedRule=structuredClone(ruleItems);changedRule[0].system.rules[0].slug='new-slug';changedRule[0].system.rules[2].suboptions[0].value='different';
const changedRuleResult=runtime.translateItems({value:changedRule,translation:rulePatches});
assert.equal(changedRuleResult[0].system.rules[0].label,'Claw');assert.equal(changedRuleResult[0].system.rules[2].suboptions[0].label,'Swarm Form');
const spellItem=[{_id:'scroll1',name:'Scroll',system:{spell:{_id:'spell1',name:'Magic',system:{description:{value:'Magic body'},level:{value:2}}}}}];
const spellPatch=[{id:'scroll1',expectedName:'Scroll',extraFields:[{path:'system.spell.name',expected:'Magic',text:'魔法',guards:[{path:'system.spell._id',expected:'spell1'}]}]}];
assert.equal(runtime.translateItems({value:spellItem,translation:spellPatch})[0].system.spell.name,'魔法');
assert.equal(spellItem[0].system.spell.name,'Magic');
const staleSpell=structuredClone(spellItem);staleSpell[0].system.spell._id='spell2';
assert.equal(runtime.translateItems({value:staleSpell,translation:spellPatch})[0].system.spell.name,'Magic');
const noSpellGuard=structuredClone(spellPatch);delete noSpellGuard[0].extraFields[0].guards;
assert.equal(runtime.translateItems({value:spellItem,translation:noSpellGuard})[0].system.spell.name,'Magic');

// Explicit correction regression tests use the same native mapping and registry.
await import(pathToFileURL(path.join(W,'032-feedback/holy-converter-tests.mjs'))).then(m=>m.testHolyCorrection({runtime,registry,FieldMapping,original,messages}));
for(const [system,active,version]of [['pf2e',false,'2.4.0'],['other',true,'2.4.0']]){
 game.system.id=system;game.modules.set('sf2e-anachronism',{active,version});
 let count=0;const result=runtime.registerLocalization({register(){count++;},registerConverter(){count++;}});
 assert.equal(result.registered,false);assert.equal(count,0);
}
game.system.id='pf2e';
for (const version of ['2.4.0','2.4.1','2.5.0','3.0.0']) {
 game.modules.set('sf2e-anachronism',{active:true,version});
 registered=[];const before=messages.length;
 callbacks.get('babele.init')(facade);callbacks.get('setup')();callbacks.get('ready')();
 assert(registered.some(x=>x.lang==='zh-Hans.custom'));
 assert.equal(messages.length,before);
}
game.modules.delete('sf2e-anachronism');
callbacks.get('babele.init')(facade);callbacks.get('ready')();assert(messages.at(-1).includes('未安装'));
const manifest=JSON.parse(await fs.readFile(path.join(R,'module.json'),'utf8'));
assert.equal(manifest.compatibility.verified,'14');
assert.equal(manifest.compatibility.maximum,'14');
assert.deepEqual(manifest.relationships.requires.find(x=>x.id==='sf2e-anachronism').compatibility,{minimum:'2.4.0'});
game.modules.set('sf2e-anachronism',{active:true,version:'2.4.0'});
const savedError=console.error;console.error=()=>{};
try{callbacks.get('babele.init')({registerConverter(){throw new Error('test registration failure');}});callbacks.get('ready')();}finally{console.error=savedError;}
assert(messages.at(-1).includes('test registration failure'));
assert.equal(coreReads,0);
const result={version:'full-localization-draft',babeleVersion:'2.9.1',babeleSourceCommit:'49c42edc3f2939934ed1d7105600914b3c8d58a2',babeleSource:'https://gitlab.com/riccisi/foundryvtt-babele/-/tree/2.9.1',objectsChecked:checked,matchedTranslations:matched,nativeMappedFields:fields,embeddedArraysChecked:embedded,nativeEntryMatching:true,nativeFieldMapping:true,inputUnchanged:true,completeTargetComparison:true,staleTextGuards:true,reorderedEmbeddedItems:true,registrationGuards:true,earlyUnregisteredCoreSettingReproduced:true,coreLanguageSettingReads:coreReads,unresolvedLanguageAtInit:true,lateLanguageRegisteredAtSetup:true,languagesChecked:['cn','cn.foundry_chn','zh','zh-CN','zh-cn','zh-Hans','zh-hans','zh-Hans.custom','en'],versionMismatchNotification:false,missingSourceNotification:true,futureVersionRegistrationChecked:["2.4.1","2.5.0","3.0.0"],holyCorrectionExactVersionGuardRetained:true,registrationFailureNotification:true,translationFilesDiscovered:Object.keys(original).length,orderedHtmlTagsUnchanged:true,orderedMacroBodiesUnchanged:true,ruleDataUnchanged:false,ruleDataUnchangedExceptAuthorizedCorrection:true,authorizedMechanicalCorrection:{pack:'sf2e-anachronism.equipment',id:'he1AD9ck10fLSvWn',path:'system.rules.1.value',from:3,to:2},mechanicalExceptions,liveFoundryTested:false};
await fs.writeFile(path.join(W,result.version.replaceAll('.','')+'-validation.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));
