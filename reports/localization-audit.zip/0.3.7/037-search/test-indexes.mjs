import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';
const D=path.dirname(fileURLToPath(import.meta.url)),W=path.dirname(D),R=path.join(W,'anachronism-cn');
const native=path.join(W,'babele-native-2.9.1');
const {installFoundryStubs}=await import(pathToFileURL(path.join(native,'tests/helpers/foundry-stubs.js')));
installFoundryStubs();
const {MappedCompendium}=await import(pathToFileURL(path.join(native,'module/script/compendium/mapped-compendium.js')));
const {default:BabeleFacade}=await import(pathToFileURL(path.join(native,'module/script/babele.js')));
const fullFacade=new BabeleFacade();
// Exercise the exact reference implementation, exposing private helpers only in this fixture.
const referencePath=path.join(W,'pf2e-cn-current-reference/babele-ondemand-patch.js');
const reference=await fs.readFile(referencePath,'utf8');
const fixture=path.join(D,'ondemand-fixture.mjs');
await fs.writeFile(fixture,reference+'\nexport {loadTitleIndex, loadLabels, translateIndexTitles, applyLabels};\n');
const demand=await import(pathToFileURL(fixture));
const load=async file=>JSON.parse(await fs.readFile(file,'utf8'));
const catalog=await load(path.join(R,'tools/source-names.json'));
const settings=new Map([['core.language','cn.foundry_chn'],['babele.directory',''],['babele.sourcePriority',{}]]);
game.settings.get=(ns,key)=>settings.get(ns+'.'+key);
game.user={isGM:true,hasPermission:()=>true};
let missing=true;const requests=[];
globalThis.fetch=async url=>{
 requests.push(url);
 assert(url.startsWith('modules/sf2e-anachronism-zh-cn/translations/'));
 assert(/\/(titles|labels)\.json$/.test(url),'Must not load full packs to search');
 if(missing)return {ok:false,status:404};
 return {ok:true,json:()=>load(path.join(R,'translations',url.split('/').at(-1)))};
};
const createFacade=()=>({modules:[{module:'sf2e-anachronism-zh-cn',lang:'cn.foundry_chn',dir:'translations'}],__ondemandPatch:{}});
const broken=createFacade();
const absent=await demand.loadTitleIndex(broken);
const classPack=catalog.packs['sf2e-anachronism.classes'];
const mysticId=Object.entries(classPack.names).find(([,n])=>n==='Mystic')[0];
const before=[{_id:mysticId,name:'Mystic'}];
demand.translateIndexTitles({titleIndex:absent},before,'sf2e-anachronism.classes');
assert.equal(before[0].name,'Mystic');assert(!before.some(e=>e.name.includes('秘术师')));
missing=false;
const fixed=createFacade();
const titles=await demand.loadTitleIndex(fixed),labels=await demand.loadLabels(fixed);
assert.equal(titles['sf2e-anachronism.classes'].titles[mysticId],'秘术师 Mystic');
let count=0,nativeCount=0;
for(const [collection,source]of Object.entries(catalog.packs)){
 const translation=await load(path.join(R,'translations',collection+'.json'));
 const old=await load(path.join(D,collection+'.json'));
 // Actual native index path, using the same name mapping as the translation file.
 const nativePack=new MappedCompendium({id:collection,name:collection.split('.').at(-1),type:source.type},
   {label:translation.label,mapping:{name:translation.mapping.name},entries:translation.entries},
   {documentMappings:fullFacade.documentMappings});
 const rows=Object.entries(source.names).map(([_id,name])=>({_id,name,img:'unchanged.webp',type:'test',system:{slug:'unchanged-slug'}}));
 const nativeRows=structuredClone(rows);nativePack.translateIndex(nativeRows);
 demand.translateIndexTitles({titleIndex:titles},rows,collection);
 const once=structuredClone(rows);demand.translateIndexTitles({titleIndex:titles},rows,collection);assert.deepEqual(rows,once);
 for(let i=0;i<rows.length;i++){
  const row=rows[i],patch=translation.entries[row._id],original=source.names[row._id];
  assert.equal(row._id,nativeRows[i]._id);assert.equal(row.system.slug,'unchanged-slug');assert.equal(row.img,'unchanged.webp');
  if(typeof patch?.name==='string'){
   assert.equal(row.name,patch.name);assert.equal(nativeRows[i].name,patch.name);
   assert.equal(row.originalName,original);assert.equal(nativeRows[i].originalName,original);
   assert(row.name.toLowerCase().includes(original.toLowerCase()),collection+'/'+original);
   const oldName=old.entries[row._id]?.name;
   if(/[\u3400-\u9fff]/.test(oldName))assert(row.name.includes(oldName));
   const byName=[{name:original}];demand.translateIndexTitles({titleIndex:titles},byName,collection);assert.equal(byName[0].name,row.name);
   count++;nativeCount++;
  }
 }
 assert.equal(labels[collection],translation.label);assert(labels[collection].includes(source.label));
 const noNames=structuredClone(translation),noOldNames=structuredClone(old);
 delete noNames.label;delete noOldNames.label;
 for(const e of Object.values(noNames.entries))if(e&&typeof e==='object')delete e.name;
 for(const e of Object.values(noOldNames.entries))if(e&&typeof e==='object')delete e.name;
 assert.deepEqual(noNames,noOldNames,'Non-name fields changed: '+collection);
}
const mystic=[{_id:mysticId,name:'Mystic'}];demand.translateIndexTitles({titleIndex:titles},mystic,'sf2e-anachronism.classes');
assert(mystic.filter(e=>e.name.includes('秘术师')).length===1);assert(mystic.filter(e=>e.name.toLowerCase().includes('mystic')).length===1);
// Players without browsing permission use the GM-shared title index.
settings.set('babele.titleIndex',titles);settings.set('babele.labels',labels);game.user.hasPermission=()=>false;
const fetched=requests.length;assert.deepEqual(await demand.loadTitleIndex(createFacade()),titles);assert.deepEqual(await demand.loadLabels(createFacade()),labels);assert.equal(requests.length,fetched);
const unrelated=[{_id:mysticId,name:'Mystic'}];demand.translateIndexTitles({titleIndex:titles},unrelated,'pf2e.classes');assert.equal(unrelated[0].name,'Mystic');
const unknown=[{_id:'new-item',name:'Future Item'}];demand.translateIndexTitles({titleIndex:titles},unknown,'sf2e-anachronism.classes');assert.equal(unknown[0].name,'Future Item');
const result={version:'0.3.7',reproducedMissingIndex:true,lightIndexNamesChecked:count,nativeIndexNamesChecked:nativeCount,packsChecked:Object.keys(catalog.packs).length,chineseAndEnglishSearch:true,gmAndPlayerIndexPaths:true,noFullPackFetchRequired:true,idAndNameLookup:true,idempotent:true,unrelatedPackUnchanged:true,unknownEntryUnchanged:true,descriptionsRulesLinksUnchangedByIndexGeneration:true,liveFoundryTested:false,referenceCommit:'11aa2358f1373ec1228871e0db93c20a5680abf6'};
await fs.writeFile(path.join(D,'validation.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
